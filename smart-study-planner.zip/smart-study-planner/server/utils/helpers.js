const mongoose = require('mongoose');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// Only copy whitelisted fields from req.body (stops clients setting user, score, etc.)
const pick = (obj = {}, keys) => keys.reduce((r, k) => { if (obj[k] !== undefined) r[k] = obj[k]; return r; }, {});

// Find a document that belongs to this user, otherwise 404.
async function owned(Model, id, userId, label = 'Item') {
  if (!mongoose.isValidObjectId(id)) throw new HttpError(400, `Invalid ${label.toLowerCase()} id`);
  const doc = await Model.findOne({ _id: id, user: userId });
  if (!doc) throw new HttpError(404, `${label} not found`);
  return doc;
}

// Treat '' as "not set" for reference fields.
function cleanRefs(data) {
  ['subject', 'topic'].forEach((k) => { if (data[k] === '') data[k] = null; });
  return data;
}

// Make sure subject/topic IDs belong to the logged-in user and match each other.
async function checkRefs(userId, m) {
  const Subject = require('../models/Subject');
  const Topic = require('../models/Topic');
  if (m.subject) await owned(Subject, m.subject, userId, 'Subject');
  if (m.topic) {
    const t = await owned(Topic, m.topic, userId, 'Topic');
    if (!m.subject || String(t.subject) !== String(m.subject)) throw new HttpError(400, 'Topic does not belong to the selected subject');
  }
}

// Generic owner-scoped CRUD. Every query includes { user: req.user.id }.
function crud({ Model, label, fields, filters = [], populate, sort = { createdAt: -1 }, query, before, after, onDelete }) {
  return {
    list: asyncHandler(async (req, res) => {
      const q = { user: req.user.id, ...(query ? query(req) : {}) };
      filters.forEach((f) => { if (req.query[f]) q[f] = String(req.query[f]); });
      const page = Math.max(1, parseInt(req.query.page) || 1);
      const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 50));
      let cursor = Model.find(q).sort(sort).skip((page - 1) * limit).limit(limit);
      if (populate) cursor = cursor.populate(populate);
      const [data, total] = await Promise.all([cursor, Model.countDocuments(q)]);
      res.json({ data, pagination: { page, pages: Math.ceil(total / limit) || 1, total } });
    }),
    get: asyncHandler(async (req, res) => {
      let doc = await owned(Model, req.params.id, req.user.id, label);
      if (populate) doc = await doc.populate(populate);
      res.json({ data: doc });
    }),
    create: asyncHandler(async (req, res) => {
      const data = pick(req.body, fields);
      if (before) await before(req, data, null);
      let doc = await Model.create({ ...data, user: req.user.id });
      if (after) await after(req, doc);
      if (populate) doc = await doc.populate(populate);
      res.status(201).json({ data: doc });
    }),
    update: asyncHandler(async (req, res) => {
      let doc = await owned(Model, req.params.id, req.user.id, label);
      const data = pick(req.body, fields);
      if (before) await before(req, data, doc);
      doc.set(data);
      await doc.save();
      if (after) await after(req, doc);
      if (populate) doc = await doc.populate(populate);
      res.json({ data: doc });
    }),
    remove: asyncHandler(async (req, res) => {
      const doc = await owned(Model, req.params.id, req.user.id, label);
      if (onDelete) await onDelete(doc);
      await doc.deleteOne();
      res.json({ message: `${label} deleted` });
    }),
  };
}

module.exports = { HttpError, asyncHandler, pick, owned, cleanRefs, checkRefs, crud };
