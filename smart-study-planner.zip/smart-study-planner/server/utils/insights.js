const Subject = require('../models/Subject');
const Topic = require('../models/Topic');
const StudySession = require('../models/StudySession');
const Task = require('../models/Task');
const QuizAttempt = require('../models/QuizAttempt');

const DAY = 86400000;
const WEAK_BELOW = 60; // a topic is "weak" when its average quiz score is below 60%
const DIFFICULTY_WEIGHT = { easy: 0, medium: 5, hard: 10 };

const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || '');
const isTime = (s) => /^([01]\d|2[0-3]):[0-5]\d$/.test(s || '');
const localToday = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const localTime = () => { const d = new Date(); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const lastDays = (n, today) => Array.from({ length: n }, (_, i) => new Date(new Date(today + 'T00:00:00Z').getTime() - (n - 1 - i) * DAY).toISOString().slice(0, 10));
const minutes = (s) => { const [a, b] = s.startTime.split(':').map(Number); const [c, d] = s.endTime.split(':').map(Number); return c * 60 + d - (a * 60 + b); };
const hours = (m) => Math.round((m / 60) * 10) / 10;
const avg = (arr) => (arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null);

async function load(userId) {
  const q = { user: userId };
  const [subjects, topics, sessions, tasks, attempts] = await Promise.all([
    Subject.find(q).lean(),
    Topic.find(q).lean(),
    StudySession.find(q).lean(),
    Task.find(q).lean(),
    QuizAttempt.find(q).select('quiz subject topic percentage createdAt').populate('quiz', 'title').sort({ createdAt: 1 }).lean(),
  ]);
  return { subjects, topics, sessions, tasks, attempts };
}

// Adds progress stats to each subject: completed topics / total topics, and studied hours.
async function withStats(userId, subjects) {
  const [topics, sessions] = await Promise.all([
    Topic.find({ user: userId }).select('subject status').lean(),
    StudySession.find({ user: userId, status: 'completed' }).select('subject startTime endTime').lean(),
  ]);
  return subjects.map((s) => {
    const t = topics.filter((x) => String(x.subject) === String(s._id));
    const done = t.filter((x) => x.status === 'completed').length;
    const m = sessions.filter((x) => String(x.subject) === String(s._id)).reduce((a, x) => a + minutes(x), 0);
    return {
      ...s,
      stats: {
        topics: t.length,
        completedTopics: done,
        inProgressTopics: t.filter((x) => x.status === 'in_progress').length,
        percent: t.length ? Math.round((done / t.length) * 100) : 0,
        studiedHours: hours(m),
      },
    };
  });
}

function topicAverages(attempts) {
  const map = {};
  attempts.forEach((a) => { (map[a.topic] = map[a.topic] || []).push(a.percentage); });
  return Object.fromEntries(Object.entries(map).map(([k, v]) => [k, { avg: avg(v), attempts: v.length }]));
}

/*
 Revision priority score (higher = revise sooner):
   weakness  = (60 - averageQuizPercent) if the average is below 60, else 0
   recency   = days since last revised (capped at 30)
   difficulty= easy 0, medium 5, hard 10 (from the subject)
   overdue   = +10 if a pending task linked to the topic is overdue
 A topic is recommended when it is weak, overdue, or started but not revised for 7+ days.
*/
function recommendations(ctx, today, limit = 6) {
  const stats = topicAverages(ctx.attempts);
  const subjects = Object.fromEntries(ctx.subjects.map((s) => [s._id, s]));
  const now = new Date(today + 'T00:00:00Z').getTime();
  const out = [];
  ctx.topics.forEach((t) => {
    const subject = subjects[t.subject];
    if (!subject) return;
    const st = stats[t._id];
    const avgScore = st ? st.avg : null;
    const ref = t.lastRevisedAt || t.createdAt;
    const days = Math.max(0, Math.floor((now - new Date(ref).getTime()) / DAY));
    const weak = avgScore !== null && avgScore < WEAK_BELOW;
    const overdue = ctx.tasks.some((k) => String(k.topic) === String(t._id) && k.status !== 'completed' && k.deadline < today);
    const stale = t.status !== 'not_started' && days >= 7;
    if (!weak && !overdue && !stale) return;
    const reasons = [];
    if (weak) reasons.push(`Average quiz score is ${avgScore}%`);
    if (overdue) reasons.push('Has an overdue task');
    if (stale) reasons.push(`Not revised for ${days} days`);
    const score = (weak ? WEAK_BELOW - avgScore : 0) + Math.min(days, 30) + (DIFFICULTY_WEIGHT[subject.difficulty] || 0) + (overdue ? 10 : 0);
    out.push({
      topicId: t._id, topic: t.name, subjectId: subject._id, subject: subject.name, color: subject.color,
      status: t.status, avgScore, daysSinceRevised: days, priorityScore: score, reasons,
    });
  });
  return out.sort((a, b) => b.priorityScore - a.priorityScore).slice(0, limit);
}

function weakTopics(ctx) {
  const stats = topicAverages(ctx.attempts);
  const subjects = Object.fromEntries(ctx.subjects.map((s) => [s._id, s]));
  return ctx.topics
    .filter((t) => stats[t._id] && stats[t._id].avg < WEAK_BELOW && subjects[t.subject])
    .map((t) => ({ topicId: t._id, topic: t.name, subject: subjects[t.subject].name, color: subjects[t.subject].color, avgScore: stats[t._id].avg, attempts: stats[t._id].attempts }))
    .sort((a, b) => a.avgScore - b.avgScore);
}

function dailyHours(ctx, days, today) {
  const done = ctx.sessions.filter((s) => s.status === 'completed');
  return days.map((d) => ({ date: d, hours: hours(done.filter((s) => s.date === d).reduce((a, s) => a + minutes(s), 0)) }));
}

// Consistency = days with at least one completed session in the last 7 days / 7
function consistency(ctx, today) {
  const set = new Set(ctx.sessions.filter((s) => s.status === 'completed').map((s) => s.date));
  const active = lastDays(7, today).filter((d) => set.has(d)).length;
  return { activeDays: active, percent: Math.round((active / 7) * 100) };
}

async function dashboard(userId, user, today) {
  const ctx = await load(userId);
  const done = ctx.sessions.filter((s) => s.status === 'completed');
  const subjectsById = Object.fromEntries(ctx.subjects.map((s) => [s._id, s]));
  const topicsById = Object.fromEntries(ctx.topics.map((t) => [t._id, t]));
  const todayHours = hours(done.filter((s) => s.date === today).reduce((a, s) => a + minutes(s), 0));
  const week = lastDays(7, today);
  const weekly = dailyHours(ctx, week, today).map((d) => ({ ...d, label: new Date(d.date + 'T00:00:00Z').toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' }) }));
  const stats = await withStats(userId, ctx.subjects);
  return {
    totals: {
      subjects: ctx.subjects.length,
      studyHours: hours(done.reduce((a, s) => a + minutes(s), 0)),
      tasksCompleted: ctx.tasks.filter((t) => t.status === 'completed').length,
      tasksPending: ctx.tasks.filter((t) => t.status !== 'completed').length,
      avgQuizScore: avg(ctx.attempts.map((a) => a.percentage)),
      quizAttempts: ctx.attempts.length,
    },
    dailyGoal: { targetHours: user.dailyGoalHours, doneHours: todayHours, percent: Math.min(100, Math.round((todayHours / user.dailyGoalHours) * 100)) },
    weeklyGoal: { targetHours: user.weeklyGoalHours, doneHours: hours(weekly.reduce((a, d) => a + d.hours * 60, 0)) },
    consistency: consistency(ctx, today),
    todaySessions: ctx.sessions
      .filter((s) => s.date === today)
      .sort((a, b) => a.startTime.localeCompare(b.startTime))
      .map((s) => ({ ...s, subject: subjectsById[s.subject] ? { _id: s.subject, name: subjectsById[s.subject].name, color: subjectsById[s.subject].color } : null, topic: topicsById[s.topic] ? { _id: s.topic, name: topicsById[s.topic].name } : null })),
    upcomingDeadlines: ctx.tasks
      .filter((t) => t.status !== 'completed')
      .sort((a, b) => a.deadline.localeCompare(b.deadline))
      .slice(0, 5)
      .map((t) => ({ ...t, overdue: t.deadline < today, subjectName: subjectsById[t.subject]?.name || null })),
    weeklyHours: weekly,
    subjectProgress: stats.map((s) => ({ id: s._id, name: s.name, color: s.color, percent: s.stats.percent, studiedHours: s.stats.studiedHours, targetHours: s.targetHours })),
    recommendations: recommendations(ctx, today, 5),
  };
}

async function analytics(userId, today) {
  const ctx = await load(userId);
  const subjects = Object.fromEntries(ctx.subjects.map((s) => [s._id, s]));
  const done = ctx.sessions.filter((s) => s.status === 'completed');
  const perSubject = ctx.subjects.map((s) => {
    const scores = ctx.attempts.filter((a) => String(a.subject) === String(s._id)).map((a) => a.percentage);
    const m = done.filter((x) => String(x.subject) === String(s._id)).reduce((a, x) => a + minutes(x), 0);
    return { id: s._id, name: s.name, color: s.color, avgScore: avg(scores), attempts: scores.length, studyHours: hours(m) };
  });
  const completed = ctx.tasks.filter((t) => t.status === 'completed').length;
  return {
    scoresOverTime: ctx.attempts.map((a) => ({ date: a.createdAt, percentage: a.percentage, quiz: a.quiz?.title || 'Quiz', subject: subjects[a.subject]?.name || '' })),
    subjectPerformance: perSubject,
    dailyHours: dailyHours(ctx, lastDays(14, today), today).map((d) => ({ ...d, label: d.date.slice(5) })),
    totalStudyHours: hours(done.reduce((a, s) => a + minutes(s), 0)),
    taskCompletion: { completed, total: ctx.tasks.length, percent: ctx.tasks.length ? Math.round((completed / ctx.tasks.length) * 100) : 0 },
    consistency: consistency(ctx, today),
    weakTopics: weakTopics(ctx),
    recommendations: recommendations(ctx, today, 8),
    hasData: ctx.attempts.length > 0 || done.length > 0 || ctx.tasks.length > 0,
  };
}

async function notifications(userId, today, time) {
  const ctx = await load(userId);
  const items = [];
  ctx.tasks.filter((t) => t.status !== 'completed' && t.deadline < today).forEach((t) => items.push({ id: 't' + t._id, type: 'danger', text: `Overdue task: ${t.title}`, link: '/tasks' }));
  ctx.tasks.filter((t) => t.status !== 'completed' && t.deadline === today).forEach((t) => items.push({ id: 'd' + t._id, type: 'warn', text: `Due today: ${t.title}`, link: '/tasks' }));
  ctx.sessions.filter((s) => s.status === 'planned' && (s.date < today || (s.date === today && s.endTime < time))).forEach((s) => items.push({ id: 'o' + s._id, type: 'danger', text: `Missed session on ${s.date} (${s.startTime}-${s.endTime})`, link: '/planner' }));
  ctx.sessions.filter((s) => s.status === 'planned' && s.date === today && s.endTime >= time).forEach((s) => items.push({ id: 's' + s._id, type: 'info', text: `Session today at ${s.startTime}`, link: '/planner' }));
  return items.slice(0, 15);
}

module.exports = { load, withStats, recommendations, dashboard, analytics, notifications, minutes, isDate, isTime, localToday, localTime };
