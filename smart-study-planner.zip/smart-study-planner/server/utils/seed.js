// Optional DEVELOPMENT data. Creates a clearly-labelled demo account with sample subjects, topics and quizzes.
// It does NOT create fake sessions, tasks or quiz attempts - those stay empty until you use the app.
// Run:  npm run seed      Login: demo@studyplanner.test / Demo@1234
require('dotenv').config();
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const User = require('../models/User');
const Subject = require('../models/Subject');
const Topic = require('../models/Topic');
const Quiz = require('../models/Quiz');
const StudySession = require('../models/StudySession');
const Task = require('../models/Task');
const QuizAttempt = require('../models/QuizAttempt');

const q = (text, options, correctIndex, explanation) => ({ text, options, correctIndex, explanation });

const DATA = [
  {
    name: 'Data Structures', color: '#2E3C84', difficulty: 'hard', targetHours: 40, description: 'Core data structures and their complexity.',
    topics: [
      { name: 'Arrays', chapter: 'Linear Structures', quiz: [
        q('What is the time complexity of accessing an array element by index?', ['O(1)', 'O(n)', 'O(log n)', 'O(n^2)'], 0, 'Arrays use contiguous memory, so index access is constant time.'),
        q('Which operation is costly in a static array?', ['Reading by index', 'Inserting in the middle', 'Getting the length', 'Overwriting an element'], 1, 'Inserting in the middle shifts all later elements.'),
        q('Arrays store elements in...', ['Random memory locations', 'Contiguous memory', 'A tree', 'A hash table'], 1, 'Contiguous memory is what makes index access fast.'),
      ] },
      { name: 'Linked Lists', chapter: 'Linear Structures' },
      { name: 'Stacks and Queues', chapter: 'Linear Structures', quiz: [
        q('Which principle does a stack follow?', ['FIFO', 'LIFO', 'Random', 'Priority'], 1, 'Last In, First Out.'),
        q('Which principle does a queue follow?', ['LIFO', 'FIFO', 'LILO only', 'Sorted'], 1, 'First In, First Out.'),
        q('Which structure is used for function call tracking?', ['Queue', 'Stack', 'Heap array', 'Graph'], 1, 'The call stack stores active function calls.'),
      ] },
      { name: 'Binary Trees', chapter: 'Trees' },
    ],
  },
  {
    name: 'Database Management', color: '#1F9D6B', difficulty: 'medium', targetHours: 30, description: 'SQL, normalization and transactions.',
    topics: [
      { name: 'Normalization', chapter: 'Design', quiz: [
        q('Normalization mainly reduces...', ['Redundancy', 'Security', 'Indexes', 'Tables'], 0, 'It removes duplicate data and update anomalies.'),
        q('A table is in 1NF when...', ['It has no partial dependency', 'All values are atomic', 'It has no transitive dependency', 'It has one row'], 1, '1NF requires atomic (single-valued) columns.'),
        q('2NF removes...', ['Partial dependency', 'Transitive dependency', 'Multi-valued columns', 'Foreign keys'], 0, '2NF removes partial dependency on part of a composite key.'),
      ] },
      { name: 'SQL Joins', chapter: 'Queries' },
      { name: 'Transactions', chapter: 'Concurrency' },
    ],
  },
];

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    const email = 'demo@studyplanner.test';
    const old = await User.findOne({ email });
    if (old) {
      const id = old._id;
      await Promise.all([Subject, Topic, Quiz, StudySession, Task, QuizAttempt].map((M) => M.deleteMany({ user: id })));
      await old.deleteOne();
    }
    const user = await User.create({ name: 'Demo Student', email, passwordHash: await bcrypt.hash('Demo@1234', 12) });
    for (const s of DATA) {
      const subject = await Subject.create({ user: user._id, name: s.name, color: s.color, difficulty: s.difficulty, targetHours: s.targetHours, description: s.description });
      for (const t of s.topics) {
        const topic = await Topic.create({ user: user._id, subject: subject._id, name: t.name, chapter: t.chapter });
        if (t.quiz) await Quiz.create({ user: user._id, subject: subject._id, topic: topic._id, title: `${t.name} Basics`, timeLimitMinutes: 5, questions: t.quiz });
      }
    }
    console.log('Seed complete. Login: demo@studyplanner.test / Demo@1234');
  } catch (e) {
    console.error('Seed failed:', e.message);
  } finally {
    await mongoose.disconnect();
  }
})();
