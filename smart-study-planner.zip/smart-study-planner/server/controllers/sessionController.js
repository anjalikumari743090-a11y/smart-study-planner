const StudySession = require('../models/StudySession');
const Topic = require('../models/Topic');
const { asyncHandler, owned, crud, cleanRefs, checkRefs, HttpError } = require('../utils/helpers');
const { isDate } = require('../utils/insights');

const touchTopic = (userId, topicId) => topicId && Topic.updateOne({ _id: topicId, user: userId }, { $set: { lastRevisedAt: new Date() } });

const c = crud({
  Model: StudySession,
  label: 'Session',
  fields: ['subject', 'topic', 'date', 'startTime', 'endTime', 'priority', 'status', 'notes'],
  filters: ['subject', 'status', 'priority', 'date'],
  sort: { date: 1, startTime: 1 },
  populate: [{ path: 'subject', select: 'name color' }, { path: 'topic', select: 'name' }],
  query: (req) => {
    const q = {};
    if (isDate(req.query.from) || isDate(req.query.to)) {
      q.date = {};
      if (isDate(req.query.from)) q.date.$gte = req.query.from;
      if (isDate(req.query.to)) q.date.$lte = req.query.to;
    }
    return q;
  },
  before: async (req, data, existing) => {
    cleanRefs(data);
    const m = { ...(existing ? existing.toObject() : {}), ...data };
    await checkRefs(req.user.id, m);
    if (m.startTime && m.endTime && m.startTime >= m.endTime) throw new HttpError(400, 'End time must be after start time');
    if (data.status === 'completed' && (!existing || existing.status !== 'completed')) data.completedAt = new Date();
    if (data.status === 'planned') data.completedAt = null;
    // Overlap check: two sessions overlap when one starts before the other ends and ends after the other starts.
    const clash = await StudySession.findOne({
      user: req.user.id, date: m.date, _id: { $ne: existing?._id },
      startTime: { $lt: m.endTime }, endTime: { $gt: m.startTime },
    });
    if (clash) throw new HttpError(409, `This overlaps another session (${clash.startTime}-${clash.endTime} on ${clash.date}).`);
  },
  after: async (req, doc) => { if (doc.status === 'completed') await touchTopic(req.user.id, doc.topic); },
});

Object.assign(exports, c);

exports.complete = asyncHandler(async (req, res) => {
  const s = await owned(StudySession, req.params.id, req.user.id, 'Session');
  s.status = 'completed';
  s.completedAt = new Date();
  await s.save();
  await touchTopic(req.user.id, s.topic);
  res.json({ data: await s.populate([{ path: 'subject', select: 'name color' }, { path: 'topic', select: 'name' }]) });
});
