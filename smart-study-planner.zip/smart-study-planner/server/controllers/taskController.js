const Task = require('../models/Task');
const { asyncHandler, owned, crud, cleanRefs, checkRefs } = require('../utils/helpers');

const populate = [{ path: 'subject', select: 'name color' }, { path: 'topic', select: 'name' }];

const c = crud({
  Model: Task,
  label: 'Task',
  fields: ['title', 'description', 'type', 'deadline', 'priority', 'status', 'subject', 'topic'],
  filters: ['status', 'priority', 'type', 'subject'],
  sort: { status: -1, deadline: 1 },
  populate,
  before: async (req, data, existing) => {
    cleanRefs(data);
    await checkRefs(req.user.id, { ...(existing ? existing.toObject() : {}), ...data });
    if (data.status) data.completedAt = data.status === 'completed' ? new Date() : null;
  },
});

Object.assign(exports, c);

exports.toggle = asyncHandler(async (req, res) => {
  const t = await owned(Task, req.params.id, req.user.id, 'Task');
  t.status = t.status === 'completed' ? 'pending' : 'completed';
  t.completedAt = t.status === 'completed' ? new Date() : null;
  await t.save();
  res.json({ data: await t.populate(populate) });
});
