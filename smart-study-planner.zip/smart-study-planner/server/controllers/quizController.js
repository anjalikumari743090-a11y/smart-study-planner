const Quiz = require('../models/Quiz');
const QuizAttempt = require('../models/QuizAttempt');
const Topic = require('../models/Topic');
const { asyncHandler, owned, crud, cleanRefs, checkRefs, HttpError } = require('../utils/helpers');

const populate = [{ path: 'subject', select: 'name color' }, { path: 'topic', select: 'name' }];

const c = crud({
  Model: Quiz,
  label: 'Quiz',
  fields: ['subject', 'topic', 'title', 'timeLimitMinutes', 'questions'],
  populate,
  before: async (req, data, existing) => {
    cleanRefs(data);
    const m = { ...(existing ? existing.toObject() : {}), ...data };
    if (!m.subject || !m.topic) throw new HttpError(400, 'Choose a subject and a topic for the quiz');
    await checkRefs(req.user.id, m);
  },
  onDelete: (quiz) => QuizAttempt.deleteMany({ user: quiz.user, quiz: quiz._id }),
});

exports.create = c.create;
exports.update = c.update;
exports.remove = c.remove;
exports.edit = c.get; // owner view WITH correct answers (for the quiz editor)

exports.list = asyncHandler(async (req, res) => {
  const q = { user: req.user.id };
  ['subject', 'topic'].forEach((k) => { if (req.query[k]) q[k] = String(req.query[k]); });
  const quizzes = await Quiz.find(q).sort({ createdAt: -1 }).populate(populate).lean();
  res.json({ data: quizzes.map(({ questions, ...rest }) => ({ ...rest, questionCount: questions.length })) });
});

// Quiz for taking: correct answers and explanations are removed, so the browser never sees them.
exports.get = asyncHandler(async (req, res) => {
  const quiz = await owned(Quiz, req.params.id, req.user.id, 'Quiz');
  await quiz.populate(populate);
  const obj = quiz.toObject();
  obj.questions = obj.questions.map((q) => ({ _id: q._id, text: q.text, options: q.options }));
  res.json({ data: obj });
});

// Scoring happens here, on the server. The client only sends which option it picked.
exports.submit = asyncHandler(async (req, res) => {
  const quiz = await owned(Quiz, req.params.id, req.user.id, 'Quiz');
  const answers = Array.isArray(req.body.answers) ? req.body.answers : [];
  const picked = new Map(answers.map((a) => [String(a?.questionId), Number.isInteger(a?.selectedIndex) ? a.selectedIndex : null]));
  const results = quiz.questions.map((q) => {
    const sel = picked.get(String(q._id));
    const valid = Number.isInteger(sel) && sel >= 0 && sel < q.options.length;
    return { questionId: q._id, text: q.text, options: q.options, selectedIndex: valid ? sel : null, correctIndex: q.correctIndex, isCorrect: valid && sel === q.correctIndex, explanation: q.explanation };
  });
  const score = results.filter((r) => r.isCorrect).length;
  const total = results.length;
  const maxSeconds = quiz.timeLimitMinutes * 60 + 30;
  const attempt = await QuizAttempt.create({
    user: req.user.id, quiz: quiz._id, subject: quiz.subject, topic: quiz.topic,
    score, total, percentage: Math.round((score / total) * 100),
    timeTakenSeconds: Math.min(maxSeconds, Math.max(0, Math.round(Number(req.body.timeTakenSeconds) || 0))),
    results,
  });
  await Topic.updateOne({ _id: quiz.topic, user: req.user.id }, { $set: { lastRevisedAt: new Date() } });
  res.status(201).json({ data: attempt });
});

/* ---------------- Attempts ---------------- */
exports.listAttempts = asyncHandler(async (req, res) => {
  const q = { user: req.user.id };
  if (req.query.quiz) q.quiz = String(req.query.quiz);
  const data = await QuizAttempt.find(q).sort({ createdAt: -1 }).limit(50).select('-results')
    .populate('quiz', 'title').populate('subject', 'name color').populate('topic', 'name');
  res.json({ data });
});

exports.getAttempt = asyncHandler(async (req, res) => {
  const attempt = await owned(QuizAttempt, req.params.id, req.user.id, 'Attempt');
  await attempt.populate([{ path: 'quiz', select: 'title' }, { path: 'subject', select: 'name color' }, { path: 'topic', select: 'name' }]);
  res.json({ data: attempt });
});
