const Subject = require('../models/Subject');
const Topic = require('../models/Topic');
const StudySession = require('../models/StudySession');
const Task = require('../models/Task');
const Quiz = require('../models/Quiz');
const QuizAttempt = require('../models/QuizAttempt');
const { asyncHandler, pick, owned, crud } = require('../utils/helpers');
const { withStats } = require('../utils/insights');

// Delete all records that belong to a topic (sessions/tasks are kept but unlinked).
async function cascadeTopic(userId, topicIds) {
  await StudySession.updateMany({ user: userId, topic: { $in: topicIds } }, { $set: { topic: null } });
  await Task.updateMany({ user: userId, topic: { $in: topicIds } }, { $set: { topic: null } });
  const quizzes = await Quiz.find({ user: userId, topic: { $in: topicIds } }).select('_id');
  await QuizAttempt.deleteMany({ user: userId, $or: [{ quiz: { $in: quizzes.map((q) => q._id) } }, { topic: { $in: topicIds } }] });
  await Quiz.deleteMany({ _id: { $in: quizzes.map((q) => q._id) } });
}

const base = crud({
  Model: Subject,
  label: 'Subject',
  fields: ['name', 'description', 'color', 'targetHours', 'difficulty'],
  onDelete: async (subject) => {
    const topics = await Topic.find({ user: subject.user, subject: subject._id }).select('_id');
    await cascadeTopic(subject.user, topics.map((t) => t._id));
    await Topic.deleteMany({ user: subject.user, subject: subject._id });
    await StudySession.deleteMany({ user: subject.user, subject: subject._id });
    await Task.deleteMany({ user: subject.user, subject: subject._id });
    await QuizAttempt.deleteMany({ user: subject.user, subject: subject._id });
    await Quiz.deleteMany({ user: subject.user, subject: subject._id });
  },
});

exports.create = base.create;
exports.update = base.update;
exports.remove = base.remove;

exports.list = asyncHandler(async (req, res) => {
  const subjects = await Subject.find({ user: req.user.id }).sort({ createdAt: -1 }).lean();
  res.json({ data: await withStats(req.user.id, subjects) });
});

exports.get = asyncHandler(async (req, res) => {
  const subject = await owned(Subject, req.params.id, req.user.id, 'Subject');
  const [data] = await withStats(req.user.id, [subject.toObject()]);
  res.json({ data });
});

/* ---------------- Topics ---------------- */
exports.listTopics = asyncHandler(async (req, res) => {
  await owned(Subject, req.params.subjectId, req.user.id, 'Subject');
  const data = await Topic.find({ user: req.user.id, subject: req.params.subjectId }).sort({ chapter: 1, createdAt: 1 });
  res.json({ data });
});

exports.createTopic = asyncHandler(async (req, res) => {
  await owned(Subject, req.params.subjectId, req.user.id, 'Subject');
  const data = pick(req.body, ['name', 'chapter', 'status']);
  if (data.status && data.status !== 'not_started') data.lastRevisedAt = new Date();
  const topic = await Topic.create({ ...data, user: req.user.id, subject: req.params.subjectId });
  res.status(201).json({ data: topic });
});

exports.updateTopic = asyncHandler(async (req, res) => {
  const topic = await owned(Topic, req.params.id, req.user.id, 'Topic');
  const data = pick(req.body, ['name', 'chapter', 'status']);
  if (data.status && data.status !== topic.status && data.status !== 'not_started') data.lastRevisedAt = new Date();
  topic.set(data);
  await topic.save();
  res.json({ data: topic });
});

exports.removeTopic = asyncHandler(async (req, res) => {
  const topic = await owned(Topic, req.params.id, req.user.id, 'Topic');
  await cascadeTopic(req.user.id, [topic._id]);
  await topic.deleteOne();
  res.json({ message: 'Topic deleted' });
});
