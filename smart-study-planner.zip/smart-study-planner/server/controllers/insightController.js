const User = require('../models/User');
const { asyncHandler } = require('../utils/helpers');
const insights = require('../utils/insights');

// The browser sends its own local date/time so "today" matches the student's timezone.
const when = (req) => ({
  today: insights.isDate(req.query.today) ? req.query.today : insights.localToday(),
  time: insights.isTime(req.query.time) ? req.query.time : insights.localTime(),
});

exports.dashboard = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id);
  res.json({ data: await insights.dashboard(req.user.id, user, when(req).today) });
});

exports.analytics = asyncHandler(async (req, res) => {
  res.json({ data: await insights.analytics(req.user.id, when(req).today) });
});

exports.recommendations = asyncHandler(async (req, res) => {
  const ctx = await insights.load(req.user.id);
  res.json({ data: insights.recommendations(ctx, when(req).today, 10) });
});

exports.notifications = asyncHandler(async (req, res) => {
  const { today, time } = when(req);
  res.json({ data: await insights.notifications(req.user.id, today, time) });
});
