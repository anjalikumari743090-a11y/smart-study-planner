const router = require('express').Router();
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');
const protect = require('../middleware/auth');
const validate = require('../middleware/validate');
const c = require('../controllers/authController');

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false, message: { message: 'Too many attempts. Please try again in 15 minutes.' } });

const email = body('email').trim().isEmail().withMessage('Enter a valid email address').normalizeEmail();
const strong = (f) => body(f).isLength({ min: 8, max: 64 }).withMessage('Password must be 8-64 characters')
  .matches(/[A-Za-z]/).withMessage('Password needs at least one letter').matches(/\d/).withMessage('Password needs at least one number');

router.post('/register', limiter, [body('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'), email, strong('password')], validate, c.register);
router.post('/login', limiter, [email, body('password').notEmpty().withMessage('Password is required')], validate, c.login);
router.get('/me', protect, c.me);
router.put('/profile', protect, [
  body('name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
  body('email').optional().trim().isEmail().withMessage('Enter a valid email address').normalizeEmail(),
  body('dailyGoalHours').optional().isFloat({ min: 0.5, max: 16 }).withMessage('Daily goal must be 0.5-16 hours'),
  body('weeklyGoalHours').optional().isFloat({ min: 1, max: 100 }).withMessage('Weekly goal must be 1-100 hours'),
  body('theme').optional().isIn(['light', 'dark']).withMessage('Theme must be light or dark'),
], validate, c.updateProfile);
router.put('/password', protect, [body('currentPassword').notEmpty().withMessage('Current password is required'), strong('newPassword')], validate, c.changePassword);

module.exports = router;
