const router = require('express').Router();
const protect = require('../middleware/auth');
const c = require('../controllers/taskController');

router.use(protect);
router.route('/').get(c.list).post(c.create);
router.route('/:id').get(c.get).put(c.update).delete(c.remove);
router.patch('/:id/toggle', c.toggle);

module.exports = router;
