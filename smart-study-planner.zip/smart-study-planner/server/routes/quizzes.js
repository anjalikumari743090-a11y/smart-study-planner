const router = require('express').Router();
const protect = require('../middleware/auth');
const c = require('../controllers/quizController');

router.use(protect);
router.get('/attempts', c.listAttempts);
router.get('/attempts/:id', c.getAttempt);
router.route('/').get(c.list).post(c.create);
router.get('/:id/edit', c.edit);
router.post('/:id/submit', c.submit);
router.route('/:id').get(c.get).put(c.update).delete(c.remove);

module.exports = router;
