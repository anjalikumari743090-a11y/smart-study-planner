const router = require('express').Router();
const protect = require('../middleware/auth');
const c = require('../controllers/subjectController');

router.use(protect);
router.route('/subjects').get(c.list).post(c.create);
router.route('/subjects/:id').get(c.get).put(c.update).delete(c.remove);
router.route('/subjects/:subjectId/topics').get(c.listTopics).post(c.createTopic);
router.route('/topics/:id').put(c.updateTopic).delete(c.removeTopic);

module.exports = router;
