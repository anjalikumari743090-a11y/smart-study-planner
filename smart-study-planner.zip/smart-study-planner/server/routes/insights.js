const router = require('express').Router();
const protect = require('../middleware/auth');
const c = require('../controllers/insightController');

router.use(protect);
router.get('/dashboard', c.dashboard);
router.get('/analytics', c.analytics);
router.get('/recommendations', c.recommendations);
router.get('/notifications', c.notifications);

module.exports = router;
