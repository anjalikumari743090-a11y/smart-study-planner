const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verifies the JWT and sets req.user.id. User IDs are NEVER taken from the request body.
module.exports = async function protect(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ')) return res.status(401).json({ message: 'Not authorized. Please log in.' });
    const { id } = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    const user = await User.findById(id).select('_id');
    if (!user) return res.status(401).json({ message: 'This account no longer exists.' });
    req.user = { id: user._id.toString() };
    next();
  } catch (err) {
    res.status(401).json({ message: 'Session expired or invalid. Please log in again.' });
  }
};
