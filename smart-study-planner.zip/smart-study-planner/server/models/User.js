const { Schema, model } = require('mongoose');

const userSchema = new Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 50 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true, select: false }, // never returned by default
    dailyGoalHours: { type: Number, default: 2, min: 0.5, max: 16 },
    weeklyGoalHours: { type: Number, default: 14, min: 1, max: 100 },
    theme: { type: String, enum: ['light', 'dark'], default: 'light' },
  },
  { timestamps: true }
);

userSchema.methods.toSafe = function () {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    dailyGoalHours: this.dailyGoalHours,
    weeklyGoalHours: this.weeklyGoalHours,
    theme: this.theme,
  };
};

module.exports = model('User', userSchema);
