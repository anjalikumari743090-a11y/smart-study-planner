const mongoose = require('mongoose');
const { Schema } = mongoose;

const questionSchema = new Schema({
  text: { type: String, required: true, trim: true, maxlength: 500 },
  options: {
    type: [{ type: String, required: true, trim: true, maxlength: 200 }],
    validate: [(v) => v.length >= 2 && v.length <= 6, 'Each question needs 2 to 6 options'],
  },
  correctIndex: {
    type: Number,
    required: true,
    min: 0,
    validate: [function (v) { return Number.isInteger(v) && v < this.options.length; }, 'Correct answer must match one of the options'],
  },
  explanation: { type: String, trim: true, maxlength: 500, default: '' },
});

const quizSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
    topic: { type: Schema.Types.ObjectId, ref: 'Topic', required: true },
    title: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
    timeLimitMinutes: { type: Number, default: 10, min: 1, max: 180 },
    questions: {
      type: [questionSchema],
      validate: [(v) => v.length >= 1 && v.length <= 50, 'A quiz needs 1 to 50 questions'],
    },
  },
  { timestamps: true }
);
quizSchema.index({ user: 1, subject: 1, topic: 1 });

module.exports = mongoose.model('Quiz', quizSchema);
