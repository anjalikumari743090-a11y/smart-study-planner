const { Schema, model } = require('mongoose');

// Chapters are stored as a string on each topic (no separate Chapter collection = no duplicated data).
const topicSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
    chapter: { type: String, trim: true, maxlength: 80, default: 'General' },
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
    status: { type: String, enum: ['not_started', 'in_progress', 'completed'], default: 'not_started' },
    lastRevisedAt: { type: Date, default: null },
  },
  { timestamps: true }
);
topicSchema.index({ user: 1, subject: 1 });

module.exports = model('Topic', topicSchema);
