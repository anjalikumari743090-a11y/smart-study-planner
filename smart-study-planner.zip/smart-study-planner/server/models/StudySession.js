const { Schema, model } = require('mongoose');

const studySessionSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
    topic: { type: Schema.Types.ObjectId, ref: 'Topic', default: null },
    date: { type: String, required: true, match: [/^\d{4}-\d{2}-\d{2}$/, 'Date must be YYYY-MM-DD'] },
    startTime: { type: String, required: true, match: [/^([01]\d|2[0-3]):[0-5]\d$/, 'Start time must be HH:mm'] },
    endTime: { type: String, required: true, match: [/^([01]\d|2[0-3]):[0-5]\d$/, 'End time must be HH:mm'] },
    priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
    status: { type: String, enum: ['planned', 'completed'], default: 'planned' },
    notes: { type: String, trim: true, maxlength: 300, default: '' },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);
studySessionSchema.index({ user: 1, date: 1 });

module.exports = model('StudySession', studySessionSchema);
