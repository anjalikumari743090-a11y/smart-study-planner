const { Schema, model } = require('mongoose');

const taskSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true, trim: true, minlength: 2, maxlength: 120 },
    description: { type: String, trim: true, maxlength: 300, default: '' },
    type: { type: String, enum: ['revision', 'goal'], default: 'revision' },
    deadline: { type: String, required: true, match: [/^\d{4}-\d{2}-\d{2}$/, 'Deadline must be YYYY-MM-DD'] },
    priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
    status: { type: String, enum: ['pending', 'completed'], default: 'pending' },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', default: null },
    topic: { type: Schema.Types.ObjectId, ref: 'Topic', default: null },
    completedAt: { type: Date, default: null },
  },
  { timestamps: true }
);
taskSchema.index({ user: 1, status: 1, deadline: 1 });

module.exports = model('Task', taskSchema);
