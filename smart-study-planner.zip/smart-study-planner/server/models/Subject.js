const { Schema, model } = require('mongoose');

const subjectSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
    description: { type: String, trim: true, maxlength: 300, default: '' },
    color: { type: String, default: '#2E3C84', match: [/^#[0-9a-fA-F]{6}$/, 'Color must be a hex value like #2E3C84'] },
    targetHours: { type: Number, default: 20, min: 1, max: 1000 },
    difficulty: { type: String, enum: ['easy', 'medium', 'hard'], default: 'medium' },
  },
  { timestamps: true }
);
subjectSchema.index({ user: 1, name: 1 }, { unique: true });

module.exports = model('Subject', subjectSchema);
