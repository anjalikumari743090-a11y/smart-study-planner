const { Schema, model } = require('mongoose');

// Results are a snapshot, so editing a quiz later never rewrites past attempts.
const resultSchema = new Schema(
  {
    questionId: Schema.Types.ObjectId,
    text: String,
    options: [String],
    selectedIndex: { type: Number, default: null },
    correctIndex: Number,
    isCorrect: Boolean,
    explanation: String,
  },
  { _id: false }
);

const quizAttemptSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    quiz: { type: Schema.Types.ObjectId, ref: 'Quiz', required: true },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
    topic: { type: Schema.Types.ObjectId, ref: 'Topic', required: true },
    score: { type: Number, required: true },
    total: { type: Number, required: true },
    percentage: { type: Number, required: true },
    timeTakenSeconds: { type: Number, default: 0 },
    results: [resultSchema],
  },
  { timestamps: true }
);
quizAttemptSchema.index({ user: 1, topic: 1 });
quizAttemptSchema.index({ user: 1, createdAt: -1 });

module.exports = model('QuizAttempt', quizAttemptSchema);
