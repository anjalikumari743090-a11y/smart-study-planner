import { useEffect } from 'react';
import { X, Loader2, AlertTriangle, Inbox } from 'lucide-react';

export const cx = (...c) => c.filter(Boolean).join(' ');

export function Spinner({ className = '' }) { return <Loader2 className={cx('animate-spin', className)} size={18} aria-label="Loading" />; }

export function Skeleton({ className = 'h-24' }) { return <div className={cx('animate-pulse rounded-xl bg-line/70', className)} />; }

export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  );
}

export function Modal({ open, title, onClose, children, wide }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-ink/60 p-4 sm:items-center" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className={cx('card my-8 w-full p-5 sm:p-6', wide ? 'max-w-3xl' : 'max-w-lg')}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-bold">{title}</h2>
          <button className="rounded-md p-1 text-muted hover:bg-app" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({ open, title, message, confirmText = 'Delete', onConfirm, onCancel, busy }) {
  return (
    <Modal open={open} title={title} onClose={onCancel}>
      <p className="text-sm text-muted">{message}</p>
      <div className="mt-5 flex justify-end gap-2">
        <button className="btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn-danger" onClick={onConfirm} disabled={busy}>{busy && <Spinner />} {confirmText}</button>
      </div>
    </Modal>
  );
}

export function StatCard({ icon: Icon, label, value, hint }) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted">{label}</span>
        {Icon && <Icon size={18} className="text-muted" />}
      </div>
      <div className="mt-2 font-display text-3xl font-bold">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted">{hint}</div>}
    </div>
  );
}

export function ProgressBar({ percent = 0, color, label }) {
  const p = Math.max(0, Math.min(100, percent));
  return (
    <div>
      {label && <div className="mb-1 flex justify-between text-xs text-muted"><span>{label}</span><span>{p}%</span></div>}
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-line" role="progressbar" aria-valuenow={p} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${p}%`, background: color || 'rgb(var(--primary))' }} />
      </div>
    </div>
  );
}

const TONES = {
  gray: 'bg-line text-fg', green: 'bg-ok/15 text-ok', red: 'bg-bad/15 text-bad', amber: 'bg-warn/20 text-warn', blue: 'bg-primary/15 text-primary',
};
export function Badge({ tone = 'gray', children }) { return <span className={cx('badge', TONES[tone])}>{children}</span>; }

export const PRIORITY_TONE = { low: 'gray', medium: 'amber', high: 'red' };
export const STATUS_TONE = { not_started: 'gray', in_progress: 'amber', completed: 'green', planned: 'blue', pending: 'amber' };
export const STATUS_LABEL = { not_started: 'Not started', in_progress: 'In progress', completed: 'Completed', planned: 'Planned', pending: 'Pending' };

export function EmptyState({ title, text, action }) {
  return (
    <div className="card flex flex-col items-center px-6 py-10 text-center">
      <Inbox className="mb-3 text-muted" size={28} />
      <h3 className="text-lg font-semibold">{title}</h3>
      {text && <p className="mt-1 max-w-sm text-sm text-muted">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="card flex flex-col items-center px-6 py-10 text-center">
      <AlertTriangle className="mb-3 text-bad" size={28} />
      <h3 className="text-lg font-semibold">Could not load this page</h3>
      <p className="mt-1 text-sm text-muted">{message}</p>
      {onRetry && <button className="btn-ghost mt-4" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function Field({ label, error, children, hint }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-muted">{hint}</p>}
      {error && <p className="mt-1 text-xs text-bad">{error}</p>}
    </div>
  );
}

export function PageLoader() {
  return <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><Skeleton /><Skeleton /><Skeleton /><Skeleton /><Skeleton className="h-64 sm:col-span-2" /><Skeleton className="h-64 sm:col-span-2" /></div>;
}
