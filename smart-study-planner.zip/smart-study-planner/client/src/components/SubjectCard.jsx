import { Link } from 'react-router-dom';
import { Pencil, Trash2 } from 'lucide-react';
import { Badge, ProgressBar } from './ui';

const DIFF = { easy: 'green', medium: 'amber', hard: 'red' };

export default function SubjectCard({ subject, onEdit, onDelete }) {
  const s = subject.stats;
  return (
    <div className="card overflow-hidden">
      <div className="h-2" style={{ background: subject.color }} />
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <Link to={`/subjects/${subject._id}`} className="min-w-0 hover:underline"><h3 className="truncate text-lg font-bold">{subject.name}</h3></Link>
          <Badge tone={DIFF[subject.difficulty]}>{subject.difficulty}</Badge>
        </div>
        <p className="mt-1 line-clamp-2 min-h-[2.5rem] text-sm text-muted">{subject.description || 'No description'}</p>
        <div className="mt-4 space-y-3">
          <ProgressBar percent={s.percent} color={subject.color} label={`${s.completedTopics} of ${s.topics} topics done`} />
          <ProgressBar percent={Math.min(100, Math.round((s.studiedHours / subject.targetHours) * 100))} color={subject.color} label={`${s.studiedHours}h of ${subject.targetHours}h target`} />
        </div>
        <div className="mt-4 flex items-center justify-between">
          <Link to={`/subjects/${subject._id}`} className="text-sm font-semibold text-primary">View topics</Link>
          <div className="flex gap-1">
            <button className="rounded-md p-2 text-muted hover:bg-app" onClick={() => onEdit(subject)} aria-label="Edit subject"><Pencil size={16} /></button>
            <button className="rounded-md p-2 text-bad hover:bg-app" onClick={() => onDelete(subject)} aria-label="Delete subject"><Trash2 size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
