import { Check, Pencil, Trash2, Clock } from 'lucide-react';
import { Badge, PRIORITY_TONE } from './ui';
import { fmtDate, isOverdueSession, durationHours } from '../utils/format';

export default function SessionCard({ session: s, onComplete, onEdit, onDelete, showDate = true }) {
  const overdue = isOverdueSession(s);
  return (
    <div className="card flex flex-wrap items-center gap-3 p-3" style={{ borderLeft: `4px solid ${s.subject?.color || '#999'}` }}>
      <div className="min-w-0 flex-1">
        <div className={`font-semibold ${s.status === 'completed' ? 'line-through opacity-60' : ''}`}>{s.subject?.name}{s.topic ? `: ${s.topic.name}` : ''}</div>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 text-sm text-muted">
          {showDate && <span>{fmtDate(s.date)}</span>}
          <span className="inline-flex items-center gap-1"><Clock size={13} /> {s.startTime}-{s.endTime} ({durationHours(s.startTime, s.endTime)}h)</span>
        </div>
        {s.notes && <div className="mt-1 text-sm text-muted">{s.notes}</div>}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={PRIORITY_TONE[s.priority]}>{s.priority}</Badge>
        {s.status === 'completed' ? <Badge tone="green">Completed</Badge> : overdue ? <Badge tone="red">Overdue</Badge> : <Badge tone="blue">Upcoming</Badge>}
        {s.status !== 'completed' && <button className="btn-ghost px-3 py-1.5" onClick={() => onComplete(s)}><Check size={15} /> Done</button>}
        {onEdit && <button className="rounded-md p-2 text-muted hover:bg-app" onClick={() => onEdit(s)} aria-label="Edit session"><Pencil size={16} /></button>}
        {onDelete && <button className="rounded-md p-2 text-bad hover:bg-app" onClick={() => onDelete(s)} aria-label="Delete session"><Trash2 size={16} /></button>}
      </div>
    </div>
  );
}
