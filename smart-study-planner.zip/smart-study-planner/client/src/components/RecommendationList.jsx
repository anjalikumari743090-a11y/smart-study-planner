import { Link } from 'react-router-dom';
import { Badge } from './ui';

export default function RecommendationList({ items }) {
  return (
    <ul className="divide-y divide-line">
      {items.map((r) => (
        <li key={r.topicId} className="flex flex-wrap items-center gap-3 py-3">
          <span className="h-8 w-1.5 rounded-full" style={{ background: r.color }} />
          <div className="min-w-0 flex-1">
            <Link to={`/subjects/${r.subjectId}`} className="font-semibold hover:underline">{r.topic}</Link>
            <div className="text-sm text-muted">{r.subject}</div>
            <div className="mt-1 flex flex-wrap gap-1.5">{r.reasons.map((x) => <Badge key={x} tone={x.startsWith('Average') || x.startsWith('Has') ? 'red' : 'amber'}>{x}</Badge>)}</div>
          </div>
          <div className="text-right text-xs text-muted">Priority<div className="font-display text-xl font-bold text-fg">{r.priorityScore}</div></div>
        </li>
      ))}
    </ul>
  );
}
