import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Field, Spinner } from './ui';
import { getTopics } from '../services/subjectService';
import { getErr } from '../utils/format';

const blankQ = () => ({ text: '', options: ['', '', '', ''], correctIndex: 0, explanation: '' });

export default function QuizForm({ initial, subjects, onSubmit, onCancel }) {
  const [f, setF] = useState({ title: '', subject: subjects[0]?._id || '', topic: '', timeLimitMinutes: 10, ...initial });
  const [questions, setQuestions] = useState(initial?.questions?.length ? initial.questions : [blankQ()]);
  const [topics, setTopics] = useState([]);
  const [errors, setErrors] = useState([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!f.subject) return;
    getTopics(f.subject).then((t) => { setTopics(t); if (!t.find((x) => x._id === f.topic)) setF((p) => ({ ...p, topic: t[0]?._id || '' })); }).catch(() => setTopics([]));
  }, [f.subject]); // eslint-disable-line

  const setQ = (i, patch) => setQuestions((qs) => qs.map((q, k) => (k === i ? { ...q, ...patch } : q)));
  const setOpt = (i, j, v) => setQ(i, { options: questions[i].options.map((o, k) => (k === j ? v : o)) });
  const addOpt = (i) => questions[i].options.length < 6 && setQ(i, { options: [...questions[i].options, ''] });
  const delOpt = (i, j) => {
    const q = questions[i];
    if (q.options.length <= 2) return;
    setQ(i, { options: q.options.filter((_, k) => k !== j), correctIndex: q.correctIndex === j ? 0 : q.correctIndex > j ? q.correctIndex - 1 : q.correctIndex });
  };

  const submit = async (e) => {
    e.preventDefault();
    const err = [];
    if (f.title.trim().length < 2) err.push('Give the quiz a title.');
    if (!f.subject || !f.topic) err.push('Choose a subject and a topic (add a topic to the subject first if none exist).');
    if (!(Number(f.timeLimitMinutes) >= 1)) err.push('Time limit must be at least 1 minute.');
    questions.forEach((q, i) => {
      if (!q.text.trim()) err.push(`Question ${i + 1}: write the question text.`);
      if (q.options.some((o) => !o.trim())) err.push(`Question ${i + 1}: fill in every option or remove the empty ones.`);
    });
    setErrors(err);
    if (err.length) return;
    setBusy(true);
    try {
      await onSubmit({
        title: f.title.trim(), subject: f.subject, topic: f.topic, timeLimitMinutes: Number(f.timeLimitMinutes),
        questions: questions.map((q) => ({ text: q.text.trim(), options: q.options.map((o) => o.trim()), correctIndex: q.correctIndex, explanation: q.explanation.trim() })),
      });
    } catch (e2) { setErrors([getErr(e2)]); } finally { setBusy(false); }
  };

  if (subjects.length === 0) return <p className="text-sm text-muted">Add a subject with at least one topic before creating a quiz.</p>;

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {errors.length > 0 && <ul className="list-disc space-y-1 rounded-lg bg-bad/10 p-3 pl-7 text-sm text-bad">{errors.map((e, i) => <li key={i}>{e}</li>)}</ul>}
      <Field label="Quiz title"><input className="input" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} autoFocus /></Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Subject"><select className="input" value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value, topic: '' })}>{subjects.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}</select></Field>
        <Field label="Topic"><select className="input" value={f.topic} onChange={(e) => setF({ ...f, topic: e.target.value })}>{topics.length === 0 && <option value="">No topics yet</option>}{topics.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}</select></Field>
        <Field label="Time limit (minutes)"><input className="input" type="number" min="1" value={f.timeLimitMinutes} onChange={(e) => setF({ ...f, timeLimitMinutes: e.target.value })} /></Field>
      </div>

      {questions.map((q, i) => (
        <div key={i} className="rounded-xl border border-line p-4">
          <div className="mb-2 flex items-center justify-between"><h3 className="font-semibold">Question {i + 1}</h3>
            {questions.length > 1 && <button type="button" className="text-bad" onClick={() => setQuestions(questions.filter((_, k) => k !== i))} aria-label={`Remove question ${i + 1}`}><Trash2 size={16} /></button>}</div>
          <textarea className="input mb-3" rows={2} placeholder="Question text" value={q.text} onChange={(e) => setQ(i, { text: e.target.value })} />
          <div className="space-y-2">
            {q.options.map((o, j) => (
              <div key={j} className="flex items-center gap-2">
                <input type="radio" name={`correct-${i}`} checked={q.correctIndex === j} onChange={() => setQ(i, { correctIndex: j })} aria-label={`Mark option ${j + 1} as correct`} className="accent-[rgb(var(--primary))]" />
                <input className="input" placeholder={`Option ${j + 1}`} value={o} onChange={(e) => setOpt(i, j, e.target.value)} />
                {q.options.length > 2 && <button type="button" className="p-1 text-muted" onClick={() => delOpt(i, j)} aria-label="Remove option"><Trash2 size={14} /></button>}
              </div>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted">Select the radio button next to the correct answer.</p>
          {q.options.length < 6 && <button type="button" className="mt-1 text-sm font-semibold text-primary" onClick={() => addOpt(i)}>+ Add option</button>}
          <input className="input mt-3" placeholder="Explanation shown after submitting (optional)" value={q.explanation} onChange={(e) => setQ(i, { explanation: e.target.value })} />
        </div>
      ))}
      <button type="button" className="btn-ghost" onClick={() => setQuestions([...questions, blankQ()])}><Plus size={16} /> Add question</button>
      <div className="flex justify-end gap-2 border-t border-line pt-4"><button type="button" className="btn-ghost" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy && <Spinner />} Save quiz</button></div>
    </form>
  );
}
