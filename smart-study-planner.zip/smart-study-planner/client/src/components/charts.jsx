import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';

const axis = { stroke: 'rgb(var(--muted))', fontSize: 12, tickLine: false, axisLine: false };
const tip = { contentStyle: { background: 'rgb(var(--surface))', border: '1px solid rgb(var(--line))', borderRadius: 8, fontSize: 12 }, cursor: { fill: 'rgb(var(--line) / 0.4)' } };

export function HoursBarChart({ data, xKey = 'label', yKey = 'hours', height = 240, unit = 'h' }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke="rgb(var(--line))" />
        <XAxis dataKey={xKey} {...axis} />
        <YAxis {...axis} allowDecimals />
        <Tooltip {...tip} formatter={(v) => [`${v}${unit}`, 'Studied']} />
        <Bar dataKey={yKey} fill="rgb(var(--primary))" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

// Horizontal bars where each bar uses the subject's own color
export function ColorBarChart({ data, valueKey, unit = '%', max = 100, height = 240 }) {
  return (
    <ResponsiveContainer width="100%" height={Math.max(height, data.length * 44)}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid horizontal={false} stroke="rgb(var(--line))" />
        <XAxis type="number" domain={max ? [0, max] : [0, 'auto']} {...axis} />
        <YAxis type="category" dataKey="name" width={110} {...axis} />
        <Tooltip {...tip} formatter={(v) => [`${v}${unit}`]} />
        <Bar dataKey={valueKey} radius={[0, 6, 6, 0]}>
          {data.map((d) => <Cell key={d.name} fill={d.color} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ScoreLineChart({ data, height = 260 }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 12, left: -20, bottom: 0 }}>
        <CartesianGrid vertical={false} stroke="rgb(var(--line))" />
        <XAxis dataKey="label" {...axis} />
        <YAxis domain={[0, 100]} {...axis} />
        <Tooltip {...tip} formatter={(v) => [`${v}%`, 'Score']} labelFormatter={(l, p) => p?.[0]?.payload?.quiz ? `${p[0].payload.quiz} (${l})` : l} />
        <Line type="monotone" dataKey="percentage" stroke="rgb(var(--primary))" strokeWidth={2.5} dot={{ r: 4 }} />
      </LineChart>
    </ResponsiveContainer>
  );
}
