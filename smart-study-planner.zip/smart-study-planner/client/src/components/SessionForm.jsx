import { useEffect, useState } from 'react';
import { Field, Spinner } from './ui';
import { getTopics } from '../services/subjectService';
import { getErr, todayStr } from '../utils/format';

export default function SessionForm({ initial, subjects, onSubmit, onCancel }) {
  const [f, setF] = useState({ subject: subjects[0]?._id || '', topic: '', date: todayStr(), startTime: '18:00', endTime: '19:00', priority: 'medium', notes: '', ...Object.fromEntries(Object.entries(initial || {}).filter(([, v]) => v !== undefined)) });
  const [topics, setTopics] = useState([]);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  useEffect(() => {
    if (!f.subject) return setTopics([]);
    getTopics(f.subject).then(setTopics).catch(() => setTopics([]));
  }, [f.subject]);

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (!f.subject) err.subject = 'Choose a subject';
    if (!f.date) err.date = 'Pick a date';
    if (!f.startTime) err.startTime = 'Required';
    if (!f.endTime) err.endTime = 'Required';
    if (f.startTime && f.endTime && f.startTime >= f.endTime) err.endTime = 'End time must be after start time';
    setErrors(err); setServerError('');
    if (Object.keys(err).length) return;
    setBusy(true);
    try { await onSubmit({ subject: f.subject, topic: f.topic || null, date: f.date, startTime: f.startTime, endTime: f.endTime, priority: f.priority, notes: f.notes }); }
    catch (e2) { setServerError(getErr(e2)); } finally { setBusy(false); }
  };

  if (subjects.length === 0) return <p className="text-sm text-muted">Add a subject first, then you can plan sessions for it.</p>;

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {serverError && <div className="rounded-lg bg-bad/10 p-3 text-sm text-bad">{serverError}</div>}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Subject" error={errors.subject}>
          <select className="input" value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value, topic: '' })}>{subjects.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}</select>
        </Field>
        <Field label="Topic (optional)">
          <select className="input" value={f.topic || ''} onChange={set('topic')}><option value="">Whole subject</option>{topics.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}</select>
        </Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Date" error={errors.date}><input className="input" type="date" value={f.date} onChange={set('date')} /></Field>
        <Field label="Start" error={errors.startTime}><input className="input" type="time" value={f.startTime} onChange={set('startTime')} /></Field>
        <Field label="End" error={errors.endTime}><input className="input" type="time" value={f.endTime} onChange={set('endTime')} /></Field>
      </div>
      <Field label="Priority"><select className="input" value={f.priority} onChange={set('priority')}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></Field>
      <Field label="Notes (optional)"><textarea className="input" rows={2} value={f.notes} onChange={set('notes')} /></Field>
      <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy && <Spinner />} Save session</button></div>
    </form>
  );
}
