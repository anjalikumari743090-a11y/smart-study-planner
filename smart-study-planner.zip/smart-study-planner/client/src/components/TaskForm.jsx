import { useEffect, useState } from 'react';
import { Field, Spinner } from './ui';
import { getTopics } from '../services/subjectService';
import { getErr, todayStr } from '../utils/format';

export default function TaskForm({ initial, subjects, onSubmit, onCancel }) {
  const [f, setF] = useState({ title: '', description: '', type: 'revision', deadline: todayStr(), priority: 'medium', subject: '', topic: '', ...initial });
  const [topics, setTopics] = useState([]);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  useEffect(() => { if (f.subject) getTopics(f.subject).then(setTopics).catch(() => setTopics([])); else setTopics([]); }, [f.subject]);

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (f.title.trim().length < 2) err.title = 'Title must be at least 2 characters';
    if (!f.deadline) err.deadline = 'Pick a deadline';
    setErrors(err); setServerError('');
    if (Object.keys(err).length) return;
    setBusy(true);
    try { await onSubmit({ title: f.title.trim(), description: f.description, type: f.type, deadline: f.deadline, priority: f.priority, subject: f.subject || null, topic: f.topic || null }); }
    catch (e2) { setServerError(getErr(e2)); } finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {serverError && <div className="rounded-lg bg-bad/10 p-3 text-sm text-bad">{serverError}</div>}
      <Field label="Title" error={errors.title}><input className="input" value={f.title} onChange={set('title')} autoFocus /></Field>
      <Field label="Details (optional)"><textarea className="input" rows={2} value={f.description} onChange={set('description')} /></Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Type"><select className="input" value={f.type} onChange={set('type')}><option value="revision">Revision task</option><option value="goal">Academic goal</option></select></Field>
        <Field label="Deadline" error={errors.deadline}><input className="input" type="date" value={f.deadline} onChange={set('deadline')} /></Field>
        <Field label="Priority"><select className="input" value={f.priority} onChange={set('priority')}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Subject (optional)"><select className="input" value={f.subject || ''} onChange={(e) => setF({ ...f, subject: e.target.value, topic: '' })}><option value="">None</option>{subjects.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}</select></Field>
        <Field label="Topic (optional)"><select className="input" value={f.topic || ''} onChange={set('topic')} disabled={!f.subject}><option value="">None</option>{topics.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}</select></Field>
      </div>
      <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy && <Spinner />} Save task</button></div>
    </form>
  );
}
