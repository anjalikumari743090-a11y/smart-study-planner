import { useState } from 'react';
import { Field, Spinner } from './ui';

const COLORS = ['#2E3C84', '#1F9D6B', '#D64550', '#E8A317', '#7A4FD6', '#0F8FA8', '#C2410C', '#475569'];

export default function SubjectForm({ initial, onSubmit, onCancel }) {
  const [f, setF] = useState({ name: '', description: '', color: COLORS[0], targetHours: 20, difficulty: 'medium', ...initial });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (f.name.trim().length < 2) err.name = 'Name must be at least 2 characters';
    if (!(Number(f.targetHours) >= 1)) err.targetHours = 'Target must be at least 1 hour';
    setErrors(err);
    if (Object.keys(err).length) return;
    setBusy(true);
    try { await onSubmit({ ...f, name: f.name.trim(), targetHours: Number(f.targetHours) }); } finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <Field label="Subject name" error={errors.name}><input className="input" value={f.name} onChange={set('name')} autoFocus /></Field>
      <Field label="Description (optional)"><textarea className="input" rows={2} value={f.description} onChange={set('description')} /></Field>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Target hours" error={errors.targetHours}><input className="input" type="number" min="1" value={f.targetHours} onChange={set('targetHours')} /></Field>
        <Field label="Difficulty">
          <select className="input" value={f.difficulty} onChange={set('difficulty')}>
            <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
          </select>
        </Field>
      </div>
      <Field label="Color">
        <div className="flex flex-wrap items-center gap-2">
          {COLORS.map((c) => (
            <button key={c} type="button" onClick={() => setF({ ...f, color: c })} aria-label={`Color ${c}`}
              className={`h-8 w-8 rounded-full border-2 ${f.color === c ? 'border-fg' : 'border-transparent'}`} style={{ background: c }} />
          ))}
          <input type="color" value={f.color} onChange={set('color')} className="h-8 w-10 cursor-pointer rounded border border-line bg-transparent" aria-label="Custom color" />
        </div>
      </Field>
      <div className="flex justify-end gap-2 pt-2">
        <button type="button" className="btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn-primary" disabled={busy}>{busy && <Spinner />} Save subject</button>
      </div>
    </form>
  );
}
