import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as auth from '../services/authService';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!localStorage.getItem('ssp_token'));

  useEffect(() => {
    if (!localStorage.getItem('ssp_token')) return;
    auth.getMe().then(setUser).catch(() => localStorage.removeItem('ssp_token')).finally(() => setLoading(false));
  }, []);

  const handleAuth = useCallback(({ token, user }) => { localStorage.setItem('ssp_token', token); setUser(user); return user; }, []);
  const login = useCallback((d) => auth.login(d).then(handleAuth), [handleAuth]);
  const register = useCallback((d) => auth.register(d).then(handleAuth), [handleAuth]);
  const logout = useCallback(() => { localStorage.removeItem('ssp_token'); setUser(null); }, []);

  return <AuthContext.Provider value={{ user, setUser, loading, login, register, logout }}>{children}</AuthContext.Provider>;
}
