import api from './api';

export const getQuizzes = (params = {}) => api.get('/quizzes', { params }).then((r) => r.data.data);
export const getQuiz = (id) => api.get(`/quizzes/${id}`).then((r) => r.data.data);          // no answers
export const getQuizForEdit = (id) => api.get(`/quizzes/${id}/edit`).then((r) => r.data.data); // with answers (owner)
export const createQuiz = (d) => api.post('/quizzes', d).then((r) => r.data.data);
export const updateQuiz = (id, d) => api.put(`/quizzes/${id}`, d).then((r) => r.data.data);
export const deleteQuiz = (id) => api.delete(`/quizzes/${id}`);
export const submitQuiz = (id, d) => api.post(`/quizzes/${id}/submit`, d).then((r) => r.data.data);
export const getAttempts = () => api.get('/quizzes/attempts').then((r) => r.data.data);
export const getAttempt = (id) => api.get(`/quizzes/attempts/${id}`).then((r) => r.data.data);
