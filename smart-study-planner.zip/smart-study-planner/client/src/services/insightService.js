import api, { clientDate } from './api';

export const getDashboard = () => api.get('/dashboard', { params: clientDate() }).then((r) => r.data.data);
export const getAnalytics = () => api.get('/analytics', { params: clientDate() }).then((r) => r.data.data);
export const getRecommendations = () => api.get('/recommendations', { params: clientDate() }).then((r) => r.data.data);
export const getNotifications = () => api.get('/notifications', { params: clientDate() }).then((r) => r.data.data);
