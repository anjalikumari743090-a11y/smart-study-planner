import api from './api';

export const getSubjects = () => api.get('/subjects').then((r) => r.data.data);
export const getSubject = (id) => api.get(`/subjects/${id}`).then((r) => r.data.data);
export const createSubject = (d) => api.post('/subjects', d).then((r) => r.data.data);
export const updateSubject = (id, d) => api.put(`/subjects/${id}`, d).then((r) => r.data.data);
export const deleteSubject = (id) => api.delete(`/subjects/${id}`);

export const getTopics = (subjectId) => api.get(`/subjects/${subjectId}/topics`).then((r) => r.data.data);
export const createTopic = (subjectId, d) => api.post(`/subjects/${subjectId}/topics`, d).then((r) => r.data.data);
export const updateTopic = (id, d) => api.put(`/topics/${id}`, d).then((r) => r.data.data);
export const deleteTopic = (id) => api.delete(`/topics/${id}`);
