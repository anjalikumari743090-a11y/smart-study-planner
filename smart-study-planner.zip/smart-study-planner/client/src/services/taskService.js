import api from './api';

export const getTasks = (params = {}) => api.get('/tasks', { params: { limit: 100, ...params } }).then((r) => r.data.data);
export const createTask = (d) => api.post('/tasks', d).then((r) => r.data.data);
export const updateTask = (id, d) => api.put(`/tasks/${id}`, d).then((r) => r.data.data);
export const deleteTask = (id) => api.delete(`/tasks/${id}`);
export const toggleTask = (id) => api.patch(`/tasks/${id}/toggle`).then((r) => r.data.data);
