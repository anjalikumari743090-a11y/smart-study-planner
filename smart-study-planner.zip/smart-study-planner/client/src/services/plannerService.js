import api from './api';

export const getSessions = (params = {}) => api.get('/sessions', { params: { limit: 100, ...params } }).then((r) => r.data.data);
export const createSession = (d) => api.post('/sessions', d).then((r) => r.data.data);
export const updateSession = (id, d) => api.put(`/sessions/${id}`, d).then((r) => r.data.data);
export const deleteSession = (id) => api.delete(`/sessions/${id}`);
export const completeSession = (id) => api.patch(`/sessions/${id}/complete`).then((r) => r.data.data);
