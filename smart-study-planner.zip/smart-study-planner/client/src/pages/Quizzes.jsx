import { useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, Play, Pencil, Trash2, Timer } from 'lucide-react';
import { PageHeader, Modal, ConfirmDialog, EmptyState, ErrorState, Skeleton, Badge } from '../components/ui';
import QuizForm from '../components/QuizForm';
import useFetch from '../hooks/useFetch';
import { getSubjects } from '../services/subjectService';
import * as api from '../services/quizService';
import { getErr, fmtDateTime, fmtSeconds } from '../utils/format';

export default function Quizzes() {
  const [subject, setSubject] = useState('');
  const quizzes = useFetch(() => api.getQuizzes(subject ? { subject } : {}), [subject]);
  const attempts = useFetch(api.getAttempts);
  const subjects = useFetch(getSubjects);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const openEdit = async (q) => {
    try { setEditing(q ? await api.getQuizForEdit(q._id) : {}); } catch (e) { toast.error(getErr(e)); }
  };
  const save = async (form) => {
    if (editing._id) await api.updateQuiz(editing._id, form); else await api.createQuiz(form);
    toast.success(editing._id ? 'Quiz updated' : 'Quiz created'); setEditing(null); quizzes.reload();
  };
  const remove = async () => {
    setBusy(true);
    try { await api.deleteQuiz(deleting._id); toast.success('Quiz deleted'); setDeleting(null); quizzes.reload(); attempts.reload(); }
    catch (e) { toast.error(getErr(e)); } finally { setBusy(false); }
  };
  const list = quizzes.data || [];

  return (
    <>
      <PageHeader title="Quizzes" subtitle="Test yourself by subject and topic. Scores are calculated on the server.">
        <select className="input w-auto" value={subject} onChange={(e) => setSubject(e.target.value)} aria-label="Filter by subject">
          <option value="">All subjects</option>{(subjects.data || []).map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}
        </select>
        <button className="btn-primary" onClick={() => openEdit(null)}><Plus size={16} /> Create quiz</button>
      </PageHeader>

      {quizzes.loading ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3"><Skeleton className="h-40" /><Skeleton className="h-40" /></div>
        : quizzes.error ? <ErrorState message={quizzes.error} onRetry={quizzes.reload} />
        : list.length === 0 ? <EmptyState title="No quizzes yet" text="Create a quiz for one of your topics. Your results will feed the weak-topic recommendations." action={<button className="btn-primary" onClick={() => openEdit(null)}><Plus size={16} /> Create quiz</button>} />
        : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((q) => (
            <div key={q._id} className="card p-4" style={{ borderTop: `4px solid ${q.subject?.color}` }}>
              <h3 className="text-lg font-bold">{q.title}</h3>
              <p className="text-sm text-muted">{q.subject?.name}: {q.topic?.name}</p>
              <div className="mt-3 flex gap-2"><Badge>{q.questionCount} questions</Badge><Badge><Timer size={12} className="mr-1" />{q.timeLimitMinutes} min</Badge></div>
              <div className="mt-4 flex items-center justify-between">
                <Link to={`/quizzes/${q._id}/take`} className="btn-primary"><Play size={15} /> Start quiz</Link>
                <div className="flex"><button className="rounded-md p-2 text-muted hover:bg-app" onClick={() => openEdit(q)} aria-label="Edit quiz"><Pencil size={16} /></button><button className="rounded-md p-2 text-bad hover:bg-app" onClick={() => setDeleting(q)} aria-label="Delete quiz"><Trash2 size={16} /></button></div>
              </div>
            </div>
          ))}
        </div>}

      <h2 className="mb-3 mt-10 text-xl font-bold">Recent attempts</h2>
      {attempts.loading ? <Skeleton className="h-24" /> : (attempts.data || []).length === 0 ? <EmptyState title="No attempts yet" text="Take a quiz and your result will appear here." />
        : <div className="card overflow-x-auto"><table className="w-full min-w-[520px] text-sm">
          <thead className="border-b border-line text-left text-muted"><tr><th className="p-3">Quiz</th><th className="p-3">Topic</th><th className="p-3">Score</th><th className="p-3">Time</th><th className="p-3">Date</th><th /></tr></thead>
          <tbody className="divide-y divide-line">{attempts.data.map((a) => (
            <tr key={a._id}><td className="p-3 font-medium">{a.quiz?.title}</td><td className="p-3">{a.topic?.name}</td>
              <td className="p-3"><Badge tone={a.percentage >= 60 ? 'green' : 'red'}>{a.score}/{a.total} ({a.percentage}%)</Badge></td>
              <td className="p-3">{fmtSeconds(a.timeTakenSeconds)}</td><td className="p-3">{fmtDateTime(a.createdAt)}</td>
              <td className="p-3 text-right"><Link className="font-semibold text-primary" to={`/attempts/${a._id}`}>Review</Link></td></tr>
          ))}</tbody></table></div>}

      <Modal open={!!editing} wide title={editing?._id ? 'Edit quiz' : 'Create quiz'} onClose={() => setEditing(null)}>
        {editing && subjects.data && <QuizForm initial={editing._id ? { ...editing, subject: editing.subject?._id || editing.subject, topic: editing.topic?._id || editing.topic } : undefined} subjects={subjects.data} onSubmit={save} onCancel={() => setEditing(null)} />}
      </Modal>
      <ConfirmDialog open={!!deleting} title="Delete quiz?" busy={busy} onCancel={() => setDeleting(null)} onConfirm={remove} message={`"${deleting?.title}" and all attempts on it will be deleted.`} />
    </>
  );
}
