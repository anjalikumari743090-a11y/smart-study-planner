import { useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { PageHeader, Modal, ConfirmDialog, EmptyState, ErrorState, Skeleton, Badge, PRIORITY_TONE } from '../components/ui';
import TaskForm from '../components/TaskForm';
import useFetch from '../hooks/useFetch';
import { getSubjects } from '../services/subjectService';
import * as api from '../services/taskService';
import { getErr, todayStr, fmtDate } from '../utils/format';

export default function Tasks() {
  const [filters, setFilters] = useState({ status: '', priority: '' });
  const query = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
  const tasks = useFetch(() => api.getTasks(query), [JSON.stringify(query)]);
  const subjects = useFetch(getSubjects);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const save = async (form) => {
    if (editing._id) await api.updateTask(editing._id, form); else await api.createTask(form);
    toast.success(editing._id ? 'Task updated' : 'Task added'); setEditing(null); tasks.reload();
  };
  const toggle = async (t) => { try { await api.toggleTask(t._id); tasks.reload(); } catch (e) { toast.error(getErr(e)); } };
  const remove = async () => {
    setBusy(true);
    try { await api.deleteTask(deleting._id); toast.success('Task deleted'); setDeleting(null); tasks.reload(); }
    catch (e) { toast.error(getErr(e)); } finally { setBusy(false); }
  };
  const list = tasks.data || [];

  return (
    <>
      <PageHeader title="Tasks and revision" subtitle="Revision tasks and academic goals with deadlines.">
        <button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> New task</button>
      </PageHeader>

      <div className="card mb-4 flex flex-wrap items-end gap-3 p-3">
        <div className="min-w-[140px] flex-1"><label className="label">Status</label><select className="input" value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}><option value="">All</option><option value="pending">Pending</option><option value="completed">Completed</option></select></div>
        <div className="min-w-[140px] flex-1"><label className="label">Priority</label><select className="input" value={filters.priority} onChange={(e) => setFilters({ ...filters, priority: e.target.value })}><option value="">All</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></div>
        <button className="btn-ghost" onClick={() => setFilters({ status: '', priority: '' })}>Reset</button>
      </div>

      {tasks.loading ? <div className="space-y-3"><Skeleton className="h-16" /><Skeleton className="h-16" /></div>
        : tasks.error ? <ErrorState message={tasks.error} onRetry={tasks.reload} />
        : list.length === 0 ? <EmptyState title="No tasks found" text="Create a revision task or a goal to stay on track." action={<button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> New task</button>} />
        : <div className="card divide-y divide-line">
          {list.map((t) => {
            const done = t.status === 'completed';
            const overdue = !done && t.deadline < todayStr();
            return (
              <div key={t._id} className="flex flex-wrap items-center gap-3 p-3">
                <input type="checkbox" className="h-5 w-5 accent-[rgb(var(--primary))]" checked={done} onChange={() => toggle(t)} aria-label={`Mark ${t.title} as ${done ? 'pending' : 'completed'}`} />
                <div className="min-w-0 flex-1">
                  <div className={`font-medium ${done ? 'line-through opacity-60' : ''}`}>{t.title}</div>
                  <div className="text-sm text-muted">Due {fmtDate(t.deadline)}{t.subject ? ` · ${t.subject.name}` : ''}{t.topic ? `: ${t.topic.name}` : ''}</div>
                </div>
                <Badge tone="gray">{t.type === 'goal' ? 'Goal' : 'Revision'}</Badge>
                <Badge tone={PRIORITY_TONE[t.priority]}>{t.priority}</Badge>
                {overdue && <Badge tone="red">Overdue</Badge>}
                {done && <Badge tone="green">Completed</Badge>}
                <button className="rounded-md p-2 text-muted hover:bg-app" onClick={() => setEditing({ ...t, subject: t.subject?._id || '', topic: t.topic?._id || '' })} aria-label="Edit task"><Pencil size={16} /></button>
                <button className="rounded-md p-2 text-bad hover:bg-app" onClick={() => setDeleting(t)} aria-label="Delete task"><Trash2 size={16} /></button>
              </div>
            );
          })}
        </div>}

      <Modal open={!!editing} title={editing?._id ? 'Edit task' : 'New task'} onClose={() => setEditing(null)}>
        {editing && <TaskForm initial={editing} subjects={subjects.data || []} onSubmit={save} onCancel={() => setEditing(null)} />}
      </Modal>
      <ConfirmDialog open={!!deleting} title="Delete task?" busy={busy} onCancel={() => setDeleting(null)} onConfirm={remove} message={`"${deleting?.title}" will be deleted.`} />
    </>
  );
}
