import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { BookOpen, Clock, CheckCircle2, Trophy, Plus, CalendarPlus, Flame, Target } from 'lucide-react';
import { PageHeader, StatCard, ProgressBar, EmptyState, ErrorState, PageLoader, Badge, PRIORITY_TONE } from '../components/ui';
import { HoursBarChart, ColorBarChart } from '../components/charts';
import SessionCard from '../components/SessionCard';
import RecommendationList from '../components/RecommendationList';
import useFetch from '../hooks/useFetch';
import { useAuth } from '../contexts/AuthContext';
import { getDashboard } from '../services/insightService';
import { completeSession } from '../services/plannerService';
import { getErr, fmtDate } from '../utils/format';

export default function Dashboard() {
  const { user } = useAuth();
  const { data: d, loading, error, reload } = useFetch(getDashboard);
  const complete = async (s) => { try { await completeSession(s._id); toast.success('Session completed'); reload(); } catch (e) { toast.error(getErr(e)); } };

  return (
    <>
      <PageHeader title={`Hello, ${user.name.split(' ')[0]}`} subtitle="Here is where your studying stands today.">
        <Link to="/subjects?new=1" className="btn-ghost"><Plus size={16} /> Add subject</Link>
        <Link to="/planner?new=1" className="btn-primary"><CalendarPlus size={16} /> New study session</Link>
      </PageHeader>

      {loading ? <PageLoader /> : error ? <ErrorState message={error} onRetry={reload} /> : (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard icon={BookOpen} label="Subjects" value={d.totals.subjects} />
            <StatCard icon={Clock} label="Study hours" value={`${d.totals.studyHours}h`} hint="From completed sessions" />
            <StatCard icon={CheckCircle2} label="Tasks" value={`${d.totals.tasksCompleted} / ${d.totals.tasksCompleted + d.totals.tasksPending}`} hint={`${d.totals.tasksPending} pending`} />
            <StatCard icon={Trophy} label="Average quiz score" value={d.totals.avgQuizScore === null ? '-' : `${d.totals.avgQuizScore}%`} hint={d.totals.quizAttempts ? `${d.totals.quizAttempts} attempts` : 'No quiz attempts yet'} />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="card p-5">
              <div className="mb-3 flex items-center gap-2 font-semibold"><Target size={18} className="text-primary" /> Today's goal</div>
              <ProgressBar percent={d.dailyGoal.percent} label={`${d.dailyGoal.doneHours}h of ${d.dailyGoal.targetHours}h`} />
              <p className="mt-2 text-xs text-muted">Weekly: {d.weeklyGoal.doneHours}h of {d.weeklyGoal.targetHours}h. Change goals in Settings.</p>
            </div>
            <div className="card p-5">
              <div className="mb-3 flex items-center gap-2 font-semibold"><Flame size={18} className="text-warn" /> Consistency</div>
              <ProgressBar percent={d.consistency.percent} label={`Studied on ${d.consistency.activeDays} of the last 7 days`} />
              <p className="mt-2 text-xs text-muted">A day counts when at least one session is marked completed.</p>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <section>
              <h2 className="mb-3 text-xl font-bold">Today's schedule</h2>
              {d.todaySessions.length === 0 ? <EmptyState title="Nothing planned for today" action={<Link to="/planner?new=1" className="btn-primary">Plan a session</Link>} />
                : <div className="space-y-3">{d.todaySessions.map((s) => <SessionCard key={s._id} session={s} showDate={false} onComplete={complete} />)}</div>}
            </section>
            <section>
              <h2 className="mb-3 text-xl font-bold">Upcoming deadlines</h2>
              {d.upcomingDeadlines.length === 0 ? <EmptyState title="No pending tasks" action={<Link to="/tasks" className="btn-primary">Add a task</Link>} />
                : <div className="card divide-y divide-line">{d.upcomingDeadlines.map((t) => (
                  <div key={t._id} className="flex items-center gap-3 p-3">
                    <div className="min-w-0 flex-1"><div className="font-medium">{t.title}</div><div className="text-sm text-muted">Due {fmtDate(t.deadline)}{t.subjectName ? ` · ${t.subjectName}` : ''}</div></div>
                    {t.overdue && <Badge tone="red">Overdue</Badge>}<Badge tone={PRIORITY_TONE[t.priority]}>{t.priority}</Badge>
                  </div>))}</div>}
            </section>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <section className="card p-5">
              <h2 className="mb-3 text-lg font-bold">Study hours this week</h2>
              {d.weeklyHours.every((x) => x.hours === 0) ? <EmptyState title="No completed sessions this week" text="Mark a session as done and it shows up here." /> : <HoursBarChart data={d.weeklyHours} />}
            </section>
            <section className="card p-5">
              <h2 className="mb-3 text-lg font-bold">Subject progress</h2>
              {d.subjectProgress.length === 0 ? <EmptyState title="No subjects yet" action={<Link to="/subjects?new=1" className="btn-primary">Add subject</Link>} /> : <ColorBarChart data={d.subjectProgress} valueKey="percent" />}
            </section>
          </div>

          <section className="card p-5">
            <h2 className="mb-1 text-lg font-bold">Revise next</h2>
            <p className="mb-2 text-sm text-muted">Ranked from your quiz scores, overdue tasks, difficulty and time since last revision.</p>
            {d.recommendations.length === 0 ? <EmptyState title="Nothing to revise right now" text="Take quizzes and study topics. Weak or neglected topics will appear here." action={<Link to="/quizzes" className="btn-primary">Go to quizzes</Link>} /> : <RecommendationList items={d.recommendations} />}
          </section>
        </div>
      )}
    </>
  );
}
