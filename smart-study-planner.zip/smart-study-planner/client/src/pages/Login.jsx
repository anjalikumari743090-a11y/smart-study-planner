import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Eye, EyeOff } from 'lucide-react';
import AuthLayout from '../layouts/AuthLayout';
import { Field, Spinner } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { getErr } from '../utils/format';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) err.email = 'Enter a valid email address';
    if (!form.password) err.password = 'Password is required';
    setErrors(err);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      const user = await login(form);
      toast.success(`Welcome back, ${user.name.split(' ')[0]}`);
      navigate(location.state?.from || '/dashboard', { replace: true });
    } catch (e2) { toast.error(getErr(e2)); setErrors({ form: getErr(e2) }); } finally { setBusy(false); }
  };

  return (
    <AuthLayout title="Log in" subtitle="Pick up where you left off." footer={<>New here? <Link className="font-semibold text-primary" to="/register">Create an account</Link></>}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {errors.form && <div className="rounded-lg bg-bad/10 p-3 text-sm text-bad">{errors.form}</div>}
        <Field label="Email" error={errors.email}><input className="input" type="email" autoComplete="email" value={form.email} onChange={set('email')} /></Field>
        <Field label="Password" error={errors.password}>
          <div className="relative">
            <input className="input pr-10" type={show ? 'text' : 'password'} autoComplete="current-password" value={form.password} onChange={set('password')} />
            <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-muted" onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
          </div>
        </Field>
        <button className="btn-primary w-full py-2.5" disabled={busy}>{busy && <Spinner />} Log in</button>
      </form>
    </AuthLayout>
  );
}
