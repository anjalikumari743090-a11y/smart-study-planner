import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, List, CalendarDays, ChevronLeft, ChevronRight } from 'lucide-react';
import { PageHeader, Modal, ConfirmDialog, EmptyState, ErrorState, Skeleton, Badge } from '../components/ui';
import SessionForm from '../components/SessionForm';
import SessionCard from '../components/SessionCard';
import useFetch from '../hooks/useFetch';
import { getSubjects } from '../services/subjectService';
import * as api from '../services/plannerService';
import { getErr, todayStr, pad, isOverdueSession } from '../utils/format';

const monthKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;

export default function Planner() {
  const [params, setParams] = useSearchParams();
  const [view, setView] = useState('list');
  const [filters, setFilters] = useState({ subject: '', status: '', date: '' });
  const [month, setMonth] = useState(monthKey(new Date()));
  const [selectedDay, setSelectedDay] = useState(todayStr());
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const subjects = useFetch(getSubjects);
  const [y, m] = month.split('-').map(Number);
  const daysInMonth = new Date(y, m, 0).getDate();

  const query = useMemo(() => {
    const q = {};
    if (filters.subject) q.subject = filters.subject;
    if (filters.status) q.status = filters.status;
    if (view === 'calendar') { q.from = `${month}-01`; q.to = `${month}-${pad(daysInMonth)}`; }
    else if (filters.date) q.date = filters.date;
    return q;
  }, [filters, view, month, daysInMonth]);
  const sessions = useFetch(() => api.getSessions(query), [JSON.stringify(query)]);

  useEffect(() => {
    if (params.get('new') === '1') {
      setEditing({ subject: params.get('subject') || undefined });
      setParams({}, { replace: true });
    }
  }, []); // eslint-disable-line

  const save = async (form) => {
    if (editing._id) await api.updateSession(editing._id, form); else await api.createSession(form);
    toast.success(editing._id ? 'Session updated' : 'Session added');
    setEditing(null); sessions.reload();
  };
  const complete = async (s) => { try { await api.completeSession(s._id); toast.success('Session marked as completed'); sessions.reload(); } catch (e) { toast.error(getErr(e)); } };
  const remove = async () => {
    setBusy(true);
    try { await api.deleteSession(deleting._id); toast.success('Session deleted'); setDeleting(null); sessions.reload(); }
    catch (e) { toast.error(getErr(e)); } finally { setBusy(false); }
  };

  const list = sessions.data || [];
  const overdue = list.filter(isOverdueSession).length;
  const upcoming = list.filter((s) => s.status === 'planned' && !isOverdueSession(s)).length;
  const set = (k) => (e) => setFilters({ ...filters, [k]: e.target.value });

  const cards = (items, showDate = true) => items.map((s) => <SessionCard key={s._id} session={s} showDate={showDate} onComplete={complete} onEdit={setEditing} onDelete={setDeleting} />);
  const dayList = list.filter((s) => s.date === selectedDay);
  const blanks = new Date(y, m - 1, 1).getDay();
  const shiftMonth = (n) => setMonth(monthKey(new Date(y, m - 1 + n, 1)));

  return (
    <>
      <PageHeader title="Study planner" subtitle="Plan sessions and keep track of what is done.">
        <div className="inline-flex rounded-lg border border-line bg-surface p-1">
          <button className={`btn px-3 py-1.5 ${view === 'list' ? 'bg-primary text-onprimary' : ''}`} onClick={() => setView('list')}><List size={15} /> List</button>
          <button className={`btn px-3 py-1.5 ${view === 'calendar' ? 'bg-primary text-onprimary' : ''}`} onClick={() => setView('calendar')}><CalendarDays size={15} /> Calendar</button>
        </div>
        <button className="btn-primary" onClick={() => setEditing({ date: view === 'calendar' ? selectedDay : undefined })}><Plus size={16} /> New session</button>
      </PageHeader>

      <div className="card mb-4 flex flex-wrap items-end gap-3 p-3">
        <div className="min-w-[140px] flex-1"><label className="label">Subject</label><select className="input" value={filters.subject} onChange={set('subject')}><option value="">All subjects</option>{(subjects.data || []).map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}</select></div>
        <div className="min-w-[140px] flex-1"><label className="label">Status</label><select className="input" value={filters.status} onChange={set('status')}><option value="">All</option><option value="planned">Planned</option><option value="completed">Completed</option></select></div>
        {view === 'list' && <div className="min-w-[140px] flex-1"><label className="label">Date</label><input className="input" type="date" value={filters.date} onChange={set('date')} /></div>}
        <button className="btn-ghost" onClick={() => setFilters({ subject: '', status: '', date: '' })}>Reset</button>
        <div className="ml-auto flex gap-2"><Badge tone="red">{overdue} overdue</Badge><Badge tone="blue">{upcoming} upcoming</Badge></div>
      </div>

      {sessions.error ? <ErrorState message={sessions.error} onRetry={sessions.reload} />
        : view === 'list' ? (
          sessions.loading ? <div className="space-y-3"><Skeleton className="h-16" /><Skeleton className="h-16" /><Skeleton className="h-16" /></div>
            : list.length === 0 ? <EmptyState title="No sessions found" text="Plan a study session or change the filters." action={<button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> New session</button>} />
            : <div className="space-y-3">{cards(list)}</div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <div className="card p-4">
              <div className="mb-3 flex items-center justify-between">
                <button className="rounded-md p-2 hover:bg-app" onClick={() => shiftMonth(-1)} aria-label="Previous month"><ChevronLeft size={18} /></button>
                <h2 className="text-lg font-bold">{new Date(y, m - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</h2>
                <button className="rounded-md p-2 hover:bg-app" onClick={() => shiftMonth(1)} aria-label="Next month"><ChevronRight size={18} /></button>
              </div>
              <div className="grid grid-cols-7 gap-1 text-center text-xs text-muted">{['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => <div key={d} className="py-1">{d}</div>)}</div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: blanks }).map((_, i) => <div key={`b${i}`} />)}
                {Array.from({ length: daysInMonth }, (_, i) => {
                  const date = `${month}-${pad(i + 1)}`;
                  const items = list.filter((s) => s.date === date);
                  return (
                    <button key={date} onClick={() => setSelectedDay(date)}
                      className={`flex aspect-square flex-col items-center justify-center rounded-lg border text-sm ${selectedDay === date ? 'border-primary bg-primary/10' : 'border-transparent hover:bg-app'} ${date === todayStr() ? 'font-bold text-primary' : ''}`}>
                      {i + 1}
                      <span className="mt-0.5 flex h-1.5 gap-0.5">{items.slice(0, 3).map((s) => <i key={s._id} className="h-1.5 w-1.5 rounded-full" style={{ background: s.subject?.color }} />)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <h3 className="mb-3 font-bold">{new Date(selectedDay + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</h3>
              {sessions.loading ? <Skeleton className="h-20" /> : dayList.length === 0 ? <EmptyState title="Nothing planned" text="No sessions on this day." action={<button className="btn-primary" onClick={() => setEditing({ date: selectedDay })}><Plus size={16} /> Add session</button>} /> : <div className="space-y-3">{cards(dayList, false)}</div>}
            </div>
          </div>
        )}

      <Modal open={!!editing} title={editing?._id ? 'Edit session' : 'New study session'} onClose={() => setEditing(null)}>
        {editing && subjects.data && <SessionForm initial={editing._id ? { ...editing, subject: editing.subject?._id, topic: editing.topic?._id || '' } : editing} subjects={subjects.data} onSubmit={save} onCancel={() => setEditing(null)} />}
      </Modal>
      <ConfirmDialog open={!!deleting} title="Delete session?" busy={busy} onCancel={() => setDeleting(null)} onConfirm={remove} message="This study session will be removed from your planner." />
    </>
  );
}
