import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ArrowLeft, Plus, Pencil, Trash2, CalendarPlus } from 'lucide-react';
import { PageHeader, Modal, ConfirmDialog, EmptyState, ErrorState, Skeleton, ProgressBar, Badge, Field, Spinner, STATUS_TONE, STATUS_LABEL } from '../components/ui';
import useFetch from '../hooks/useFetch';
import * as api from '../services/subjectService';
import { getErr } from '../utils/format';

function TopicForm({ initial, chapters, onSubmit, onCancel }) {
  const [f, setF] = useState({ name: '', chapter: 'General', status: 'not_started', ...initial });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    if (f.name.trim().length < 2) return setErr('Topic name must be at least 2 characters');
    setErr(''); setBusy(true);
    try { await onSubmit({ name: f.name.trim(), chapter: f.chapter.trim() || 'General', status: f.status }); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <Field label="Topic name" error={err}><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus /></Field>
      <Field label="Chapter" hint="Pick an existing chapter or type a new one">
        <input className="input" list="chapters" value={f.chapter} onChange={(e) => setF({ ...f, chapter: e.target.value })} />
        <datalist id="chapters">{chapters.map((c) => <option key={c} value={c} />)}</datalist>
      </Field>
      <Field label="Status">
        <select className="input" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
          {Object.entries(STATUS_LABEL).filter(([k]) => ['not_started', 'in_progress', 'completed'].includes(k)).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </Field>
      <div className="flex justify-end gap-2"><button type="button" className="btn-ghost" onClick={onCancel}>Cancel</button><button className="btn-primary" disabled={busy}>{busy && <Spinner />} Save topic</button></div>
    </form>
  );
}

export default function SubjectDetail() {
  const { id } = useParams();
  const subject = useFetch(() => api.getSubject(id), [id]);
  const topics = useFetch(() => api.getTopics(id), [id]);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);
  const reloadAll = () => { subject.reload(); topics.reload(); };

  const save = async (form) => {
    try {
      if (editing._id) await api.updateTopic(editing._id, form); else await api.createTopic(id, form);
      toast.success(editing._id ? 'Topic updated' : 'Topic added'); setEditing(null); reloadAll();
    } catch (e) { toast.error(getErr(e)); }
  };
  const setStatus = async (t, status) => {
    try { await api.updateTopic(t._id, { status }); reloadAll(); } catch (e) { toast.error(getErr(e)); }
  };
  const remove = async () => {
    setBusy(true);
    try { await api.deleteTopic(deleting._id); toast.success('Topic deleted'); setDeleting(null); reloadAll(); }
    catch (e) { toast.error(getErr(e)); } finally { setBusy(false); }
  };

  if (subject.error) return <ErrorState message={subject.error} onRetry={reloadAll} />;
  const s = subject.data;
  const list = topics.data || [];
  const chapters = [...new Set(list.map((t) => t.chapter))];

  return (
    <>
      <Link to="/subjects" className="mb-4 inline-flex items-center gap-1 text-sm text-muted hover:text-fg"><ArrowLeft size={16} /> All subjects</Link>
      {!s ? <Skeleton className="h-32" /> : (
        <div className="card mb-6 overflow-hidden">
          <div className="h-2" style={{ background: s.color }} />
          <div className="grid gap-4 p-5 md:grid-cols-[1fr_320px]">
            <div>
              <h1 className="text-3xl font-bold">{s.name}</h1>
              <p className="mt-1 text-sm text-muted">{s.description || 'No description'}</p>
              <div className="mt-3 flex gap-2"><Badge tone="blue">{s.difficulty}</Badge><Badge>{s.stats.studiedHours}h of {s.targetHours}h studied</Badge></div>
            </div>
            <div className="space-y-3">
              <ProgressBar percent={s.stats.percent} color={s.color} label={`${s.stats.completedTopics} of ${s.stats.topics} topics completed`} />
              <Link to={`/planner?new=1&subject=${s._id}`} className="btn-ghost w-full"><CalendarPlus size={16} /> Plan a session</Link>
            </div>
          </div>
        </div>
      )}

      <PageHeader title="Topics" subtitle="Grouped by chapter. Change a status any time.">
        <button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> Add topic</button>
      </PageHeader>

      {topics.loading ? <Skeleton className="h-40" /> : topics.error ? <ErrorState message={topics.error} onRetry={topics.reload} />
        : list.length === 0 ? <EmptyState title="No topics yet" text="Add the chapters and topics you need to cover." action={<button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> Add topic</button>} />
        : chapters.map((ch) => (
          <section key={ch} className="mb-5">
            <h2 className="mb-2 text-lg font-bold">{ch}</h2>
            <div className="card divide-y divide-line">
              {list.filter((t) => t.chapter === ch).map((t) => (
                <div key={t._id} className="flex flex-wrap items-center gap-3 p-3">
                  <div className="min-w-0 flex-1 font-medium">{t.name}</div>
                  <Badge tone={STATUS_TONE[t.status]}>{STATUS_LABEL[t.status]}</Badge>
                  <select className="input w-auto py-1.5" value={t.status} onChange={(e) => setStatus(t, e.target.value)} aria-label={`Status of ${t.name}`}>
                    <option value="not_started">Not started</option><option value="in_progress">In progress</option><option value="completed">Completed</option>
                  </select>
                  <button className="rounded-md p-2 text-muted hover:bg-app" onClick={() => setEditing(t)} aria-label="Edit topic"><Pencil size={16} /></button>
                  <button className="rounded-md p-2 text-bad hover:bg-app" onClick={() => setDeleting(t)} aria-label="Delete topic"><Trash2 size={16} /></button>
                </div>
              ))}
            </div>
          </section>
        ))}

      <Modal open={!!editing} title={editing?._id ? 'Edit topic' : 'Add topic'} onClose={() => setEditing(null)}>
        {editing && <TopicForm initial={editing._id ? editing : undefined} chapters={chapters} onSubmit={save} onCancel={() => setEditing(null)} />}
      </Modal>
      <ConfirmDialog open={!!deleting} title="Delete topic?" busy={busy} onCancel={() => setDeleting(null)} onConfirm={remove}
        message={`"${deleting?.name}" and its quizzes and quiz attempts will be deleted. Sessions and tasks linked to it are kept but unlinked.`} />
    </>
  );
}
