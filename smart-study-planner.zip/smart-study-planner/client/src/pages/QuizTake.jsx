import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Timer, ChevronLeft, ChevronRight, ArrowLeft } from 'lucide-react';
import { Modal, ErrorState, Skeleton, Spinner, ProgressBar, cx } from '../components/ui';
import useFetch from '../hooks/useFetch';
import { getQuiz, submitQuiz } from '../services/quizService';
import { getErr, fmtSeconds } from '../utils/format';

export default function QuizTake() {
  const { id } = useParams();
  const navigate = useNavigate();
  const quiz = useFetch(() => getQuiz(id), [id]);
  const [answers, setAnswers] = useState({}); // { questionId: selectedIndex }
  const [idx, setIdx] = useState(0);
  const [left, setLeft] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const answersRef = useRef(answers);
  const started = useRef(Date.now());
  answersRef.current = answers;

  const submit = async (auto) => {
    if (submitting) return;
    setSubmitting(true); setConfirm(false);
    try {
      const attempt = await submitQuiz(id, {
        answers: Object.entries(answersRef.current).map(([questionId, selectedIndex]) => ({ questionId, selectedIndex })),
        timeTakenSeconds: Math.round((Date.now() - started.current) / 1000),
      });
      if (auto === true) toast('Time is up. Your quiz was submitted.');
      navigate(`/attempts/${attempt._id}`, { replace: true });
    } catch (e) { toast.error(getErr(e)); setSubmitting(false); }
  };

  useEffect(() => { if (quiz.data && left === null) { setLeft(quiz.data.timeLimitMinutes * 60); started.current = Date.now(); } }, [quiz.data]); // eslint-disable-line
  useEffect(() => {
    if (left === null) return;
    if (left <= 0) { submit(true); return; }
    const t = setTimeout(() => setLeft((l) => l - 1), 1000);
    return () => clearTimeout(t);
  }, [left]); // eslint-disable-line

  if (quiz.loading) return <Skeleton className="h-96" />;
  if (quiz.error) return <ErrorState message={quiz.error} onRetry={quiz.reload} />;
  const qz = quiz.data;
  const q = qz.questions[idx];
  const answered = qz.questions.filter((x) => answers[x._id] !== undefined).length;
  const unanswered = qz.questions.map((x, i) => (answers[x._id] === undefined ? i + 1 : null)).filter(Boolean);
  const low = left !== null && left <= 60;

  return (
    <>
      <Link to="/quizzes" className="mb-4 inline-flex items-center gap-1 text-sm text-muted hover:text-fg"><ArrowLeft size={16} /> Leave quiz</Link>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">{qz.title}</h1><p className="text-sm text-muted">{qz.subject?.name}: {qz.topic?.name}</p></div>
        <div className={cx('inline-flex items-center gap-2 rounded-lg border px-4 py-2 font-display text-xl font-bold', low ? 'border-bad text-bad' : 'border-line')}><Timer size={20} /> {fmtSeconds(Math.max(0, left ?? 0))}</div>
      </div>
      <div className="mb-5"><ProgressBar percent={Math.round((answered / qz.questions.length) * 100)} label={`${answered} of ${qz.questions.length} answered`} /></div>

      <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
        <div className="card p-5">
          <p className="text-sm text-muted">Question {idx + 1} of {qz.questions.length}</p>
          <h2 className="mb-5 mt-1 text-xl font-semibold">{q.text}</h2>
          <div className="space-y-2" role="radiogroup" aria-label="Answer options">
            {q.options.map((o, j) => {
              const sel = answers[q._id] === j;
              return (
                <button key={j} role="radio" aria-checked={sel} onClick={() => setAnswers({ ...answers, [q._id]: j })}
                  className={cx('flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors', sel ? 'border-primary bg-primary/10' : 'border-line hover:bg-app')}>
                  <span className={cx('grid h-7 w-7 shrink-0 place-items-center rounded-full border text-xs font-bold', sel ? 'border-primary bg-primary text-onprimary' : 'border-line')}>{String.fromCharCode(65 + j)}</span>
                  {o}
                </button>
              );
            })}
          </div>
          <div className="mt-6 flex items-center justify-between">
            <button className="btn-ghost" disabled={idx === 0} onClick={() => setIdx(idx - 1)}><ChevronLeft size={16} /> Previous</button>
            {idx < qz.questions.length - 1 ? <button className="btn-primary" onClick={() => setIdx(idx + 1)}>Next <ChevronRight size={16} /></button>
              : <button className="btn-primary" onClick={() => setConfirm(true)} disabled={submitting}>{submitting && <Spinner />} Submit quiz</button>}
          </div>
        </div>

        <aside className="card h-fit p-4">
          <h3 className="mb-3 font-semibold">Questions</h3>
          <div className="grid grid-cols-5 gap-2">
            {qz.questions.map((x, i) => (
              <button key={x._id} onClick={() => setIdx(i)} aria-label={`Go to question ${i + 1}${answers[x._id] !== undefined ? ', answered' : ', not answered'}`}
                className={cx('aspect-square rounded-lg border text-sm font-semibold', answers[x._id] !== undefined ? 'border-primary bg-primary text-onprimary' : 'border-line', i === idx && 'ring-2 ring-offset-2 ring-primary ring-offset-surface')}>{i + 1}</button>
            ))}
          </div>
          <p className="mt-3 text-xs text-muted">Filled = answered, outlined = unanswered.</p>
          <button className="btn-primary mt-4 w-full" onClick={() => setConfirm(true)} disabled={submitting}>Submit quiz</button>
        </aside>
      </div>

      <Modal open={confirm} title="Submit quiz?" onClose={() => setConfirm(false)}>
        <p className="text-sm">You answered <b>{answered}</b> of <b>{qz.questions.length}</b> questions.</p>
        {unanswered.length > 0 && <p className="mt-2 text-sm text-bad">Unanswered: question{unanswered.length > 1 ? 's' : ''} {unanswered.join(', ')}. These will be marked wrong.</p>}
        <div className="mt-5 flex justify-end gap-2"><button className="btn-ghost" onClick={() => setConfirm(false)}>Keep working</button><button className="btn-primary" onClick={() => submit(false)}>Submit now</button></div>
      </Modal>
    </>
  );
}
