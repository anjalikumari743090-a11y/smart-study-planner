import { Link, useParams } from 'react-router-dom';
import { CheckCircle2, XCircle, MinusCircle, ArrowLeft } from 'lucide-react';
import { ErrorState, Skeleton, Badge, ProgressBar, cx } from '../components/ui';
import useFetch from '../hooks/useFetch';
import { getAttempt } from '../services/quizService';
import { fmtSeconds, fmtDateTime } from '../utils/format';

export default function QuizResult() {
  const { id } = useParams();
  const { data: a, loading, error, reload } = useFetch(() => getAttempt(id), [id]);
  if (loading) return <Skeleton className="h-96" />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  const unanswered = a.results.filter((r) => r.selectedIndex === null).length;
  const wrong = a.total - a.score - unanswered;
  const pass = a.percentage >= 60;

  return (
    <>
      <Link to="/quizzes" className="mb-4 inline-flex items-center gap-1 text-sm text-muted hover:text-fg"><ArrowLeft size={16} /> Back to quizzes</Link>
      <div className="card mb-6 p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">{a.quiz?.title || 'Quiz result'}</h1>
            <p className="text-sm text-muted">{a.subject?.name}: {a.topic?.name} · {fmtDateTime(a.createdAt)} · {fmtSeconds(a.timeTakenSeconds)}</p>
          </div>
          <div className="text-right"><div className="font-display text-5xl font-bold">{a.percentage}%</div><Badge tone={pass ? 'green' : 'red'}>{pass ? 'Good result' : 'Needs revision'}</Badge></div>
        </div>
        <div className="mt-5"><ProgressBar percent={a.percentage} color={pass ? '#1F9D6B' : '#D64550'} /></div>
        <div className="mt-4 grid grid-cols-3 gap-3 text-center text-sm">
          <div className="rounded-lg bg-ok/10 p-3"><div className="text-2xl font-bold text-ok">{a.score}</div>Correct</div>
          <div className="rounded-lg bg-bad/10 p-3"><div className="text-2xl font-bold text-bad">{wrong}</div>Wrong</div>
          <div className="rounded-lg bg-line p-3"><div className="text-2xl font-bold">{unanswered}</div>Unanswered</div>
        </div>
        <div className="mt-5 flex gap-2"><Link to={`/quizzes/${a.quiz?._id}/take`} className="btn-primary">Retake quiz</Link><Link to="/analytics" className="btn-ghost">See analytics</Link></div>
      </div>

      <h2 className="mb-3 text-xl font-bold">Review</h2>
      <div className="space-y-4">
        {a.results.map((r, i) => {
          const Icon = r.selectedIndex === null ? MinusCircle : r.isCorrect ? CheckCircle2 : XCircle;
          return (
            <div key={i} className="card p-4">
              <div className="mb-3 flex items-start gap-2"><Icon size={20} className={cx('mt-0.5 shrink-0', r.isCorrect ? 'text-ok' : r.selectedIndex === null ? 'text-muted' : 'text-bad')} /><h3 className="font-semibold">{i + 1}. {r.text}</h3></div>
              <ul className="space-y-1.5">
                {r.options.map((o, j) => (
                  <li key={j} className={cx('rounded-lg border px-3 py-2 text-sm', j === r.correctIndex ? 'border-ok bg-ok/10' : j === r.selectedIndex ? 'border-bad bg-bad/10' : 'border-line')}>
                    {o} {j === r.correctIndex && <b className="ml-1 text-ok">(correct)</b>} {j === r.selectedIndex && j !== r.correctIndex && <b className="ml-1 text-bad">(your answer)</b>}
                  </li>
                ))}
              </ul>
              {r.selectedIndex === null && <p className="mt-2 text-sm text-muted">You did not answer this question.</p>}
              {r.explanation && <p className="mt-3 rounded-lg bg-app p-3 text-sm"><b>Explanation:</b> {r.explanation}</p>}
            </div>
          );
        })}
      </div>
    </>
  );
}
