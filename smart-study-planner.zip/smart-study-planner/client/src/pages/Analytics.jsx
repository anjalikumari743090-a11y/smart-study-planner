import { Link } from 'react-router-dom';
import { PageHeader, ErrorState, PageLoader, EmptyState, ProgressBar, StatCard } from '../components/ui';
import { ScoreLineChart, ColorBarChart, HoursBarChart } from '../components/charts';
import RecommendationList from '../components/RecommendationList';
import useFetch from '../hooks/useFetch';
import { getAnalytics } from '../services/insightService';
import { fmtDateTime } from '../utils/format';
import { Clock, CheckCircle2, Flame } from 'lucide-react';

export default function Analytics() {
  const { data: a, loading, error, reload } = useFetch(getAnalytics);
  if (loading) return <><PageHeader title="Performance analytics" /><PageLoader /></>;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  const scores = a.scoresOverTime.map((s) => ({ ...s, label: fmtDateTime(s.date) }));
  const perf = a.subjectPerformance.filter((s) => s.avgScore !== null);
  const hours = a.subjectPerformance.filter((s) => s.studyHours > 0).map((s) => ({ ...s, name: s.name }));

  return (
    <>
      <PageHeader title="Performance analytics" subtitle="Everything below is calculated from your own quizzes, sessions and tasks." />
      {!a.hasData && <div className="mb-6"><EmptyState title="Not enough data yet" text="Complete a study session, finish a task, or take a quiz to unlock your analytics." action={<Link to="/quizzes" className="btn-primary">Take a quiz</Link>} /></div>}

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard icon={Clock} label="Total study hours" value={`${a.totalStudyHours}h`} />
        <StatCard icon={CheckCircle2} label="Task completion" value={`${a.taskCompletion.percent}%`} hint={`${a.taskCompletion.completed} of ${a.taskCompletion.total} tasks`} />
        <StatCard icon={Flame} label="Consistency" value={`${a.consistency.percent}%`} hint={`${a.consistency.activeDays} active days in the last 7`} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Quiz scores over time</h2>
          {scores.length === 0 ? <EmptyState title="No quiz attempts yet" text="Your score history will be charted here." /> : <ScoreLineChart data={scores} />}
        </section>
        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Average score by subject</h2>
          {perf.length === 0 ? <EmptyState title="No scores yet" text="Take a quiz to see how each subject is going." /> : <ColorBarChart data={perf} valueKey="avgScore" />}
        </section>
        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Study hours, last 14 days</h2>
          {a.dailyHours.every((d) => d.hours === 0) ? <EmptyState title="No completed sessions" text="Mark sessions as done in the planner." /> : <HoursBarChart data={a.dailyHours} />}
        </section>
        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Study hours by subject</h2>
          {hours.length === 0 ? <EmptyState title="No study time logged" /> : <ColorBarChart data={hours} valueKey="studyHours" unit="h" max={0} />}
        </section>
        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Task completion</h2>
          <ProgressBar percent={a.taskCompletion.percent} label={`${a.taskCompletion.completed} of ${a.taskCompletion.total} done`} />
        </section>
        <section className="card p-5">
          <h2 className="mb-1 text-lg font-bold">Weak topics</h2>
          <p className="mb-2 text-sm text-muted">Topics with an average quiz score below 60%.</p>
          {a.weakTopics.length === 0 ? <EmptyState title="No weak topics" text={a.scoresOverTime.length ? 'Every topic you have been quizzed on is at 60% or above.' : 'Take quizzes so we can find them.'} /> : (
            <ul className="divide-y divide-line">{a.weakTopics.map((w) => (
              <li key={w.topicId} className="flex items-center gap-3 py-3"><span className="h-8 w-1.5 rounded-full" style={{ background: w.color }} /><div className="flex-1"><div className="font-semibold">{w.topic}</div><div className="text-sm text-muted">{w.subject} · {w.attempts} attempt{w.attempts > 1 ? 's' : ''}</div></div><div className="font-display text-xl font-bold text-bad">{w.avgScore}%</div></li>
            ))}</ul>
          )}
        </section>
      </div>

      <section className="card mt-6 p-5">
        <h2 className="mb-1 text-lg font-bold">Recommended for revision</h2>
        <p className="mb-2 text-sm text-muted">Priority = weakness + days since last revised + subject difficulty + overdue-task bonus.</p>
        {a.recommendations.length === 0 ? <EmptyState title="No recommendations yet" text="Recommendations appear once you have weak, neglected or overdue topics." /> : <RecommendationList items={a.recommendations} />}
      </section>
    </>
  );
}
