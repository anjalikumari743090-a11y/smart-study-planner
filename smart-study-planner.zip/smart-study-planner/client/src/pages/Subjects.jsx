import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus } from 'lucide-react';
import { PageHeader, Modal, ConfirmDialog, EmptyState, ErrorState, Skeleton } from '../components/ui';
import SubjectForm from '../components/SubjectForm';
import SubjectCard from '../components/SubjectCard';
import useFetch from '../hooks/useFetch';
import * as api from '../services/subjectService';
import { getErr } from '../utils/format';

export default function Subjects() {
  const [params, setParams] = useSearchParams();
  const q = (params.get('q') || '').toLowerCase();
  const { data, loading, error, reload } = useFetch(api.getSubjects);
  const [editing, setEditing] = useState(null); // null | {} (new) | subject
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (params.get('new') === '1') { setEditing({}); params.delete('new'); setParams(params, { replace: true }); } }, []); // eslint-disable-line

  const save = async (form) => {
    try {
      if (editing._id) await api.updateSubject(editing._id, form); else await api.createSubject(form);
      toast.success(editing._id ? 'Subject updated' : 'Subject added');
      setEditing(null); reload();
    } catch (e) { toast.error(getErr(e)); }
  };
  const remove = async () => {
    setBusy(true);
    try { await api.deleteSubject(deleting._id); toast.success('Subject deleted'); setDeleting(null); reload(); }
    catch (e) { toast.error(getErr(e)); } finally { setBusy(false); }
  };

  const list = (data || []).filter((s) => !q || s.name.toLowerCase().includes(q) || (s.description || '').toLowerCase().includes(q));

  return (
    <>
      <PageHeader title="Subjects" subtitle="Everything you are studying, with progress per subject.">
        {q && <button className="btn-ghost" onClick={() => setParams({})}>Clear search "{params.get('q')}"</button>}
        <button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> Add subject</button>
      </PageHeader>

      {loading ? <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3"><Skeleton className="h-64" /><Skeleton className="h-64" /><Skeleton className="h-64" /></div>
        : error ? <ErrorState message={error} onRetry={reload} />
        : list.length === 0 ? <EmptyState title={q ? 'No subjects match your search' : 'No subjects yet'} text={q ? 'Try a different word.' : 'Add your first subject, then break it into chapters and topics.'} action={!q && <button className="btn-primary" onClick={() => setEditing({})}><Plus size={16} /> Add subject</button>} />
        : <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{list.map((s) => <SubjectCard key={s._id} subject={s} onEdit={setEditing} onDelete={setDeleting} />)}</div>}

      <Modal open={!!editing} title={editing?._id ? 'Edit subject' : 'Add subject'} onClose={() => setEditing(null)}>
        {editing && <SubjectForm initial={editing._id ? editing : undefined} onSubmit={save} onCancel={() => setEditing(null)} />}
      </Modal>
      <ConfirmDialog open={!!deleting} title="Delete subject?" busy={busy} onCancel={() => setDeleting(null)} onConfirm={remove}
        message={`"${deleting?.name}" will be deleted together with its topics, study sessions, tasks, quizzes and quiz attempts. This cannot be undone.`} />
    </>
  );
}
