import { Link } from 'react-router-dom';
import { GraduationCap, CalendarClock, ClipboardCheck, TrendingDown, ListChecks, MoonStar, ShieldCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const FEATURES = [
  { icon: CalendarClock, title: 'A planner that catches clashes', text: 'Schedule sessions by subject and topic. If two sessions overlap, you are told before it is saved.' },
  { icon: ClipboardCheck, title: 'Quizzes scored on the server', text: 'Timed multiple-choice quizzes with explanations. Scores are calculated by the backend, so they cannot be edited in the browser.' },
  { icon: TrendingDown, title: 'Weak topics, found for you', text: 'Any topic where your quiz average falls below 60% is flagged and ranked for revision.' },
  { icon: ListChecks, title: 'Revision tasks and goals', text: 'Set deadlines and priorities, then see what is overdue at a glance.' },
  { icon: ShieldCheck, title: 'Your data stays yours', text: 'Passwords are hashed and every record is tied to your account.' },
  { icon: MoonStar, title: 'Light and dark', text: 'Studying late? Switch themes in one click.' },
];

const SAMPLE = [
  { day: 'Mon', time: '18:00-19:30', what: 'Data Structures: Linked Lists', pct: 100 },
  { day: 'Tue', time: '17:30-18:30', what: 'DBMS: Normalization quiz', pct: 70 },
  { day: 'Thu', time: '19:00-20:00', what: 'Revise: Binary Trees', pct: 30 },
];

export default function Landing() {
  const { user } = useAuth();
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold"><GraduationCap className="text-primary" /> Study Planner</Link>
        <nav className="flex items-center gap-2">
          {user ? <Link to="/dashboard" className="btn-primary">Open dashboard</Link> : <><Link to="/login" className="btn-ghost">Log in</Link><Link to="/register" className="btn-primary">Get started</Link></>}
        </nav>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pb-16 pt-8 sm:px-6 lg:grid-cols-2 lg:pt-16">
        <div>
          <h1 className="text-4xl font-bold leading-[1.1] sm:text-5xl lg:text-6xl">Revise what your scores say you are missing.</h1>
          <p className="mt-5 max-w-lg text-lg text-muted">Plan study sessions, take quizzes, and let your own results show which topics need attention next.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/register" className="btn-primary px-6 py-3 text-base">Create free account</Link>
            <Link to="/login" className="btn-ghost px-6 py-3 text-base">I already have one</Link>
          </div>
        </div>

        <div className="card ruled relative overflow-hidden p-6 pl-12 shadow-lg">
          <span className="absolute inset-y-0 left-8 w-px bg-bad/40" aria-hidden />
          <p className="mb-4 text-sm font-semibold text-muted">Example week (not real data)</p>
          <ul className="space-y-[18px]">
            {SAMPLE.map((s) => (
              <li key={s.day} className="leading-[14px]">
                <div className="flex justify-between text-sm"><span className="font-semibold">{s.day} {s.time}</span><span className="text-muted">{s.pct}%</span></div>
                <div className="text-sm text-muted">{s.what}</div>
                <div className="mt-1 h-3 rounded-sm bg-marker/30"><div className="h-3 rounded-sm bg-marker" style={{ width: `${s.pct}%` }} /></div>
              </li>
            ))}
          </ul>
          <div className="mt-8 rounded-lg bg-bad/10 p-3 text-sm"><span className="font-semibold text-bad">Revise next:</span> Binary Trees, quiz average 45%</div>
        </div>
      </section>

      <section className="border-y border-line bg-surface py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="max-w-xl text-3xl font-bold">Everything a semester needs, in one place</h2>
          <div className="mt-10 grid gap-x-12 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(({ icon: Icon, title, text }) => (
              <div key={title} className="flex gap-4">
                <Icon className="mt-1 shrink-0 text-primary" size={22} />
                <div><h3 className="font-semibold">{title}</h3><p className="mt-1 text-sm text-muted">{text}</p></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6">
        <h2 className="text-3xl font-bold">Start with one subject</h2>
        <p className="mx-auto mt-3 max-w-md text-muted">Add a subject, plan a session, and take your first quiz today.</p>
        <Link to="/register" className="btn-primary mt-6 px-6 py-3 text-base">Create free account</Link>
      </section>
      <footer className="border-t border-line py-6 text-center text-sm text-muted">Smart Study Planner, a MERN stack project</footer>
    </div>
  );
}
