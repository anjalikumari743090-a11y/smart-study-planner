import { useState } from 'react';
import toast from 'react-hot-toast';
import { Moon, Sun } from 'lucide-react';
import { PageHeader, Field, Spinner } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { updateProfile, changePassword } from '../services/authService';
import { getErr } from '../utils/format';

export default function Settings() {
  const { user, setUser } = useAuth();
  const { theme, setTheme } = useTheme();
  const [profile, setProfile] = useState({ name: user.name, email: user.email });
  const [goals, setGoals] = useState({ dailyGoalHours: user.dailyGoalHours, weeklyGoalHours: user.weeklyGoalHours });
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState('');

  const save = async (key, payload, msg) => {
    setBusy(key);
    try { setUser(await updateProfile(payload)); toast.success(msg); return true; }
    catch (e) { toast.error(getErr(e)); return false; } finally { setBusy(''); }
  };

  const saveProfile = (e) => {
    e.preventDefault();
    const err = {};
    if (profile.name.trim().length < 2) err.name = 'Name must be at least 2 characters';
    if (!/^\S+@\S+\.\S+$/.test(profile.email)) err.email = 'Enter a valid email address';
    setErrors(err);
    if (!Object.keys(err).length) save('profile', { name: profile.name.trim(), email: profile.email }, 'Profile updated');
  };
  const saveGoals = (e) => {
    e.preventDefault();
    const d = Number(goals.dailyGoalHours), w = Number(goals.weeklyGoalHours);
    const err = {};
    if (!(d >= 0.5 && d <= 16)) err.daily = 'Enter 0.5 to 16 hours';
    if (!(w >= 1 && w <= 100)) err.weekly = 'Enter 1 to 100 hours';
    setErrors(err);
    if (!Object.keys(err).length) save('goals', { dailyGoalHours: d, weeklyGoalHours: w }, 'Study goals saved');
  };
  const pickTheme = async (t) => { setTheme(t); await save('theme', { theme: t }, `${t === 'dark' ? 'Dark' : 'Light'} theme saved`); };
  const savePassword = async (e) => {
    e.preventDefault();
    const err = {};
    if (!pw.currentPassword) err.current = 'Enter your current password';
    if (pw.newPassword.length < 8 || !/[A-Za-z]/.test(pw.newPassword) || !/\d/.test(pw.newPassword)) err.new = 'Use 8+ characters with a letter and a number';
    if (pw.confirm !== pw.newPassword) err.confirm = 'Passwords do not match';
    setErrors(err);
    if (Object.keys(err).length) return;
    setBusy('pw');
    try { await changePassword({ currentPassword: pw.currentPassword, newPassword: pw.newPassword }); toast.success('Password changed'); setPw({ currentPassword: '', newPassword: '', confirm: '' }); }
    catch (e2) { toast.error(getErr(e2)); } finally { setBusy(''); }
  };

  return (
    <>
      <PageHeader title="Profile and settings" subtitle="Manage your account, study goals and appearance." />
      <div className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={saveProfile} className="card space-y-4 p-5" noValidate>
          <h2 className="text-lg font-bold">Profile</h2>
          <Field label="Name" error={errors.name}><input className="input" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} /></Field>
          <Field label="Email" error={errors.email}><input className="input" type="email" value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })} /></Field>
          <button className="btn-primary" disabled={busy === 'profile'}>{busy === 'profile' && <Spinner />} Save profile</button>
        </form>

        <form onSubmit={saveGoals} className="card space-y-4 p-5" noValidate>
          <h2 className="text-lg font-bold">Study goals</h2>
          <Field label="Daily study target (hours)" error={errors.daily}><input className="input" type="number" step="0.5" value={goals.dailyGoalHours} onChange={(e) => setGoals({ ...goals, dailyGoalHours: e.target.value })} /></Field>
          <Field label="Weekly study target (hours)" error={errors.weekly}><input className="input" type="number" step="0.5" value={goals.weeklyGoalHours} onChange={(e) => setGoals({ ...goals, weeklyGoalHours: e.target.value })} /></Field>
          <button className="btn-primary" disabled={busy === 'goals'}>{busy === 'goals' && <Spinner />} Save goals</button>
        </form>

        <section className="card p-5">
          <h2 className="mb-3 text-lg font-bold">Appearance</h2>
          <div className="flex gap-3">
            <button className={`btn flex-1 border ${theme === 'light' ? 'border-primary bg-primary/10' : 'border-line'}`} onClick={() => pickTheme('light')}><Sun size={16} /> Light</button>
            <button className={`btn flex-1 border ${theme === 'dark' ? 'border-primary bg-primary/10' : 'border-line'}`} onClick={() => pickTheme('dark')}><Moon size={16} /> Dark</button>
          </div>
        </section>

        <form onSubmit={savePassword} className="card space-y-4 p-5" noValidate>
          <h2 className="text-lg font-bold">Change password</h2>
          <Field label="Current password" error={errors.current}><input className="input" type="password" autoComplete="current-password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} /></Field>
          <Field label="New password" error={errors.new}><input className="input" type="password" autoComplete="new-password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} /></Field>
          <Field label="Confirm new password" error={errors.confirm}><input className="input" type="password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} /></Field>
          <button className="btn-primary" disabled={busy === 'pw'}>{busy === 'pw' && <Spinner />} Change password</button>
        </form>
      </div>
    </>
  );
}
