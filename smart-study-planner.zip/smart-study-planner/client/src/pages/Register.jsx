import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Eye, EyeOff } from 'lucide-react';
import AuthLayout from '../layouts/AuthLayout';
import { Field, Spinner } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { getErr } from '../utils/format';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (form.name.trim().length < 2) err.name = 'Name must be at least 2 characters';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) err.email = 'Enter a valid email address';
    if (form.password.length < 8 || !/[A-Za-z]/.test(form.password) || !/\d/.test(form.password)) err.password = 'Use 8+ characters with at least one letter and one number';
    if (form.confirm !== form.password) err.confirm = 'Passwords do not match';
    setErrors(err);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      await register({ name: form.name.trim(), email: form.email, password: form.password });
      toast.success('Account created. Welcome!');
      navigate('/dashboard', { replace: true });
    } catch (e2) { toast.error(getErr(e2)); setErrors({ form: getErr(e2) }); } finally { setBusy(false); }
  };

  return (
    <AuthLayout title="Create your account" subtitle="It takes less than a minute." footer={<>Already registered? <Link className="font-semibold text-primary" to="/login">Log in</Link></>}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        {errors.form && <div className="rounded-lg bg-bad/10 p-3 text-sm text-bad">{errors.form}</div>}
        <Field label="Full name" error={errors.name}><input className="input" autoComplete="name" value={form.name} onChange={set('name')} /></Field>
        <Field label="Email" error={errors.email}><input className="input" type="email" autoComplete="email" value={form.email} onChange={set('email')} /></Field>
        <Field label="Password" error={errors.password} hint="8+ characters, with a letter and a number">
          <div className="relative">
            <input className="input pr-10" type={show ? 'text' : 'password'} autoComplete="new-password" value={form.password} onChange={set('password')} />
            <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-muted" onClick={() => setShow(!show)} aria-label={show ? 'Hide password' : 'Show password'}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
          </div>
        </Field>
        <Field label="Confirm password" error={errors.confirm}><input className="input" type={show ? 'text' : 'password'} autoComplete="new-password" value={form.confirm} onChange={set('confirm')} /></Field>
        <button className="btn-primary w-full py-2.5" disabled={busy}>{busy && <Spinner />} Create account</button>
      </form>
    </AuthLayout>
  );
}
