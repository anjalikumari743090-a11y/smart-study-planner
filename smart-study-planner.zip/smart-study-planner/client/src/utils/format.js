export const pad = (n) => String(n).padStart(2, '0');
export const toDateStr = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const todayStr = () => toDateStr(new Date());
export const nowTime = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
export const fmtDate = (s) => (s ? new Date(s + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '');
export const fmtDateTime = (iso) => new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
export const fmtSeconds = (s) => `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
export const getErr = (e) => e?.response?.data?.message || (e?.request ? 'Cannot reach the server. Is the backend running?' : e?.message) || 'Something went wrong';
export const initials = (name = '') => name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');
export const durationHours = (start, end) => { const [a, b] = start.split(':').map(Number); const [c, d] = end.split(':').map(Number); return Math.round(((c * 60 + d - a * 60 - b) / 60) * 10) / 10; };
// A planned session is overdue once its end time has passed
export const isOverdueSession = (s) => s.status === 'planned' && (s.date < todayStr() || (s.date === todayStr() && s.endTime < nowTime()));
