import { useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useNavigate, useLocation, Link } from 'react-router-dom';
import { LayoutDashboard, BookOpen, CalendarDays, ListChecks, ClipboardCheck, BarChart3, Settings as Cog, Bell, Search, Sun, Moon, Menu, LogOut, PanelLeftClose, PanelLeftOpen, GraduationCap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { getNotifications } from '../services/insightService';
import { cx } from '../components/ui';
import { initials } from '../utils/format';

const NAV = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/subjects', label: 'Subjects', icon: BookOpen },
  { to: '/planner', label: 'Study planner', icon: CalendarDays },
  { to: '/tasks', label: 'Tasks', icon: ListChecks },
  { to: '/quizzes', label: 'Quizzes', icon: ClipboardCheck },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/settings', label: 'Settings', icon: Cog },
];

function useClickAway(ref, fn) {
  useEffect(() => {
    const h = (e) => ref.current && !ref.current.contains(e.target) && fn();
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [ref, fn]);
}

function Sidebar({ collapsed, mobileOpen, closeMobile, toggleCollapse }) {
  return (
    <>
      {mobileOpen && <div className="fixed inset-0 z-30 bg-ink/50 lg:hidden" onClick={closeMobile} />}
      <aside className={cx('fixed inset-y-0 left-0 z-40 flex flex-col bg-ink text-white transition-all duration-200 lg:static', collapsed ? 'lg:w-[72px]' : 'lg:w-64', 'w-64', mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0')}>
        <div className="flex h-16 items-center gap-2 px-5">
          <GraduationCap className="shrink-0 text-marker" />
          {!collapsed && <span className="font-display text-lg font-bold">Study Planner</span>}
        </div>
        <nav className="flex-1 space-y-1 px-3 py-2">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} onClick={closeMobile} title={label}
              className={({ isActive }) => cx('flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors', isActive ? 'bg-marker text-ink' : 'text-white/75 hover:bg-white/10 hover:text-white', collapsed && 'lg:justify-center')}>
              <Icon size={18} className="shrink-0" />
              {!collapsed && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>
        <button onClick={toggleCollapse} className="m-3 hidden items-center gap-3 rounded-lg px-3 py-2 text-sm text-white/70 hover:bg-white/10 lg:flex" aria-label="Collapse sidebar">
          {collapsed ? <PanelLeftOpen size={18} /> : <><PanelLeftClose size={18} /> Collapse</>}
        </button>
      </aside>
    </>
  );
}

function Notifications() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const ref = useRef(null);
  const location = useLocation();
  useClickAway(ref, () => setOpen(false));
  useEffect(() => { getNotifications().then(setItems).catch(() => {}); }, [location.pathname]);
  const tone = { danger: 'bg-bad', warn: 'bg-warn', info: 'bg-primary' };
  return (
    <div className="relative" ref={ref}>
      <button className="relative rounded-lg p-2 hover:bg-app" onClick={() => setOpen((o) => !o)} aria-label="Notifications">
        <Bell size={20} />
        {items.length > 0 && <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-bad px-1 text-[10px] font-bold text-white">{items.length}</span>}
      </button>
      {open && (
        <div className="card absolute right-0 z-40 mt-2 w-80 max-w-[85vw] p-2">
          <div className="px-2 py-1.5 text-sm font-semibold">Notifications</div>
          {items.length === 0 ? <p className="px-2 py-4 text-sm text-muted">You are all caught up.</p> : (
            <ul className="max-h-80 overflow-y-auto">
              {items.map((n) => (
                <li key={n.id}><Link to={n.link} onClick={() => setOpen(false)} className="flex items-start gap-2 rounded-lg px-2 py-2 text-sm hover:bg-app"><span className={cx('mt-1.5 h-2 w-2 shrink-0 rounded-full', tone[n.type])} />{n.text}</Link></li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function ProfileMenu() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const navigate = useNavigate();
  useClickAway(ref, () => setOpen(false));
  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-2 rounded-lg p-1 hover:bg-app" aria-label="Profile menu">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-sm font-bold text-onprimary">{initials(user.name)}</span>
      </button>
      {open && (
        <div className="card absolute right-0 z-40 mt-2 w-56 p-2">
          <div className="px-2 py-2"><div className="truncate text-sm font-semibold">{user.name}</div><div className="truncate text-xs text-muted">{user.email}</div></div>
          <button className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm hover:bg-app" onClick={() => { setOpen(false); navigate('/settings'); }}><Cog size={16} /> Settings</button>
          <button className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm text-bad hover:bg-app" onClick={() => { logout(); navigate('/login'); }}><LogOut size={16} /> Log out</button>
        </div>
      )}
    </div>
  );
}

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(localStorage.getItem('ssp_collapsed') === '1');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [q, setQ] = useState('');
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();

  const toggleCollapse = () => setCollapsed((c) => { localStorage.setItem('ssp_collapsed', c ? '0' : '1'); return !c; });
  const search = (e) => { e.preventDefault(); if (q.trim()) navigate(`/subjects?q=${encodeURIComponent(q.trim())}`); };

  return (
    <div className="flex min-h-screen">
      <Sidebar collapsed={collapsed} mobileOpen={mobileOpen} closeMobile={() => setMobileOpen(false)} toggleCollapse={toggleCollapse} />
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-line bg-surface/90 px-4 backdrop-blur sm:px-6">
          <button className="rounded-lg p-2 hover:bg-app lg:hidden" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <form onSubmit={search} className="relative max-w-md flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input className="input pl-9" placeholder="Search subjects" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
          </form>
          <div className="ml-auto flex items-center gap-1">
            <button className="rounded-lg p-2 hover:bg-app" onClick={toggle} aria-label="Toggle theme">{theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}</button>
            <Notifications />
            <ProfileMenu />
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 p-4 sm:p-6"><Outlet /></main>
      </div>
    </div>
  );
}
