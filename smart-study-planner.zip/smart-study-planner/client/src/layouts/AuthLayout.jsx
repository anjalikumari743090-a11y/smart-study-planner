import { Link } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';

export default function AuthLayout({ title, subtitle, children, footer }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.1fr]">
      <div className="hidden flex-col justify-between bg-ink p-10 text-white lg:flex">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold"><GraduationCap className="text-marker" /> Study Planner</Link>
        <p className="font-display text-3xl font-bold leading-snug">Plan the week. Take the quiz. Revise what the numbers point to.</p>
        <p className="text-sm text-white/60">Your subjects, sessions and scores are private to your account.</p>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <Link to="/" className="mb-8 flex items-center gap-2 font-display text-lg font-bold lg:hidden"><GraduationCap className="text-primary" /> Study Planner</Link>
          <h1 className="text-3xl font-bold">{title}</h1>
          <p className="mb-6 mt-1 text-sm text-muted">{subtitle}</p>
          {children}
          <p className="mt-6 text-center text-sm text-muted">{footer}</p>
        </div>
      </div>
    </div>
  );
}
