/** Design tokens: "ink on paper with a highlighter". Colors come from CSS variables so dark mode is one switch. */
const v = (name) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        app: v('bg'), surface: v('surface'), fg: v('text'), muted: v('muted'), line: v('line'),
        primary: v('primary'), onprimary: v('on-primary'),
        ink: '#1B2559', marker: '#FFD84D',
        ok: '#1F9D6B', warn: '#E8A317', bad: '#D64550',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
      },
      boxShadow: { card: '0 1px 2px rgb(20 27 61 / 0.06)' },
    },
  },
  plugins: [],
};
