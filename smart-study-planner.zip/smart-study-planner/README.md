# Smart Study Planner (MERN)

Students manage subjects, plan study sessions, track tasks, take quizzes and see which topics need revision.
Frontend: React + Vite + Tailwind. Backend: Express + MongoDB (Mongoose). Auth: JWT + bcrypt.

## 1. Run it on Windows

Install first: **Node.js 20 LTS or newer** (https://nodejs.org) and either a free **MongoDB Atlas** account or **MongoDB Community** locally.

### Backend (Terminal 1)
```powershell
cd server
npm install
copy .env.example .env
notepad .env        # set MONGO_URI and JWT_SECRET (see below)
npm run dev
```
You should see `MongoDB connected` and `API running on http://localhost:5000`.

### Frontend (Terminal 2)
```powershell
cd client
npm install
copy .env.example .env
npm run dev
```
Open http://localhost:5173

### Optional demo data
```powershell
cd server
npm run seed
```
Creates `demo@studyplanner.test` / `Demo@1234` with 2 sample subjects, topics and 3 quizzes. It does not create fake sessions, tasks or quiz attempts.

## 2. MongoDB setup

**Atlas (cloud):** create a free cluster, Database Access -> add a user + password, Network Access -> add your IP (or 0.0.0.0/0 for testing), Connect -> Drivers -> copy the string and put your database name in it:
`mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/smart-study-planner?retryWrites=true&w=majority`
(special characters in the password must be URL-encoded).

**Local:** install MongoDB Community, make sure the "MongoDB" Windows service is running, and use
`MONGO_URI=mongodb://127.0.0.1:27017/smart-study-planner`

**JWT_SECRET:** generate one with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

## 3. Folder structure
```
server/  config/ controllers/ middleware/ models/ routes/ utils/ server.js
client/  src/ components/ layouts/ pages/ hooks/ contexts/ services/ utils/ App.jsx main.jsx
```

## 4. Database models
| Model | Key fields | Relationships |
|---|---|---|
| User | name, email (unique), passwordHash (hidden), goals, theme | owns everything below |
| Subject | name, color, targetHours, difficulty | user; has many Topics |
| Topic | name, chapter, status, lastRevisedAt | user, subject |
| StudySession | date, startTime, endTime, priority, status | user, subject, topic? |
| Task | title, type, deadline, priority, status | user, subject?, topic? |
| Quiz | title, timeLimitMinutes, questions[] | user, subject, topic |
| QuizAttempt | score, total, percentage, results[] (snapshot) | user, quiz, subject, topic |

Every private record stores `user`, and every query filters by `req.user.id` taken from the verified JWT (never from the request body).
Deleting a subject removes its topics, sessions, tasks, quizzes and attempts (the UI asks for confirmation). Deleting a topic removes its quizzes/attempts and unlinks sessions/tasks.

## 5. How the smart features work (no paid AI)
- **Weak topic:** average quiz percentage on the topic is below 60.
- **Revision priority** = (60 - average, if weak) + days since last revised (max 30) + difficulty (easy 0, medium 5, hard 10) + 10 if a linked task is overdue. A topic is recommended if it is weak, has an overdue task, or was started but not revised for 7+ days.
- **Consistency:** days with a completed session in the last 7 days / 7.
- **Daily goal:** today's completed-session hours / your daily target (max 100%).
- **Subject progress:** completed topics / total topics.
- **Overlap detection:** a new session conflicts if an existing one on that date starts before it ends and ends after it starts.
- **Quiz scoring:** done on the server. The quiz sent to the browser has no correct answers; the client sends only the selected option per question.

## 6. API (prefix `/api`, all except register/login need `Authorization: Bearer <token>`)
Auth: `POST /auth/register`, `POST /auth/login`, `GET /auth/me`, `PUT /auth/profile`, `PUT /auth/password`
Subjects: `GET|POST /subjects`, `GET|PUT|DELETE /subjects/:id`
Topics: `GET|POST /subjects/:subjectId/topics`, `PUT|DELETE /topics/:id`
Sessions: `GET|POST /sessions`, `GET|PUT|DELETE /sessions/:id`, `PATCH /sessions/:id/complete` (filters: subject, status, priority, date, from, to)
Tasks: `GET|POST /tasks`, `GET|PUT|DELETE /tasks/:id`, `PATCH /tasks/:id/toggle`
Quizzes: `GET|POST /quizzes`, `GET /quizzes/:id` (no answers), `GET /quizzes/:id/edit`, `PUT|DELETE /quizzes/:id`, `POST /quizzes/:id/submit`, `GET /quizzes/attempts`, `GET /quizzes/attempts/:id`
Insights: `GET /dashboard`, `/analytics`, `/recommendations`, `/notifications`

Example:
```
POST /api/auth/register   {"name":"Anjali","email":"a@x.com","password":"Study1234"}
-> 201 {"token":"eyJ...","user":{"id":"...","name":"Anjali","email":"a@x.com","dailyGoalHours":2,...}}

POST /api/sessions  (Bearer token)  {"subject":"<id>","date":"2026-10-27","startTime":"18:00","endTime":"19:00"}
-> 201 {"data":{...}}      overlapping time -> 409 {"message":"This overlaps another session (18:30-19:30 on 2026-10-27)."}

POST /api/quizzes/<id>/submit  {"answers":[{"questionId":"<qid>","selectedIndex":1}],"timeTakenSeconds":95}
-> 201 {"data":{"score":2,"total":3,"percentage":67,"results":[...]}}
```
Errors look like `{"message":"..."}` with 400 / 401 / 404 / 409 / 500. Auth endpoints are rate limited (30 per 15 minutes).

## 7. Test cases to try
1. Register with a weak password -> blocked; with mismatched confirm -> blocked. Register the same email twice -> error.
2. Log in with a wrong password -> "Invalid email or password". Open `/dashboard` while logged out -> redirected to login.
3. Create 2 accounts. Copy a subject id from account A and request `/api/subjects/<id>` with account B's token -> 404.
4. Add a session 18:00-19:00, then 18:30-19:30 on the same date -> overlap error. 19:00-20:00 is allowed.
5. Mark a session done -> dashboard study hours and weekly chart update.
6. Take a quiz leaving one question blank -> result shows it as unanswered. Check DevTools Network: `GET /quizzes/:id` has no `correctIndex`.
7. Score below 60% on a topic -> it appears under Weak topics and Revise next.
8. Delete a subject -> its topics, sessions, quizzes disappear. Toggle dark mode, refresh -> theme remembered.

## 8. Troubleshooting
- `MONGO_URI is missing` -> you did not create `server/.env` (copy `.env.example`).
- `querySrv ENOTFOUND` / `ECONNREFUSED` with Atlas -> check internet, URI, and that your IP is allowed in Network Access.
- `Authentication failed` -> wrong Atlas user/password (URL-encode special characters like `@` as `%40`).
- Local MongoDB `ECONNREFUSED 127.0.0.1:27017` -> start the "MongoDB" service (Services app, or `net start MongoDB` in an Administrator terminal).
- `EADDRINUSE :5000` -> another app uses the port; change `PORT` in `server/.env` and `VITE_API_URL` in `client/.env`.
- "Cannot reach the server" in the browser -> backend is not running, or `CLIENT_URL` in `server/.env` does not match the frontend address (CORS). Restart after editing `.env`.
- `npm` scripts blocked in PowerShell -> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.

## 9. Honest limitations
- JWT is stored in localStorage (simple for a college project; httpOnly cookies are safer against XSS).
- Quiz time limit is enforced by the browser timer; the server only clamps the reported time.
- Notifications are derived from overdue/today items (no push or email).
- The backend was syntax-checked and the frontend production build succeeded, but there are no automated tests; use the manual test cases above.
